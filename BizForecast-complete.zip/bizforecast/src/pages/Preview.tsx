import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Copy, Download, FileSpreadsheet, Loader2, Pencil, Printer } from 'lucide-react';
import ReportView from '../components/report/ReportView';
import { storage } from '../lib/storage';
import { sampleReport } from '../lib/sample';
import { downloadCsv } from '../lib/csv';
import { uid } from '../lib/defaults';
import type { Orientation, Report } from '../types';

export default function Preview() {
  const { id } = useParams();
  const nav = useNavigate();
  const isDemo = id === 'sample';
  const [report, setReport] = useState<Report | undefined>(() => (isDemo ? sampleReport() : id ? storage.get(id) : undefined));
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  if (!report) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <p className="text-lg font-semibold">Report not found</p>
        <p className="mt-1 text-sm text-muted">It may have been deleted from this device.</p>
        <Link className="btn-primary btn mt-6" to="/dashboard">
          Go to dashboard
        </Link>
      </div>
    );
  }

  const setOrientation = (o: Orientation) => {
    const next = { ...report, custom: { ...report.custom, orientation: o } };
    setReport(next);
    if (!isDemo) storage.save(next);
  };

  const pdf = async () => {
    setBusy(true);
    setMsg('');
    try {
      // Loaded on demand to keep the first page load fast
      const { downloadPdf } = await import('../lib/pdf');
      downloadPdf(report);
      setMsg('PDF downloaded.');
    } catch (e) {
      console.error(e);
      setMsg('Sorry, the PDF could not be created. Please try again, or use Print → Save as PDF.');
    } finally {
      setBusy(false);
    }
  };

  const copyDemo = () => {
    const copy: Report = { ...sampleReport(), id: uid(), createdAt: new Date().toISOString() };
    copy.business = { ...copy.business, name: `${copy.business.name} (copy)` };
    storage.save(copy);
    nav(`/edit/${copy.id}`);
  };

  return (
    <div className="mx-auto max-w-5xl px-3 py-5 sm:px-4 sm:py-8">
      <div className="no-print mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <button className="btn-ghost btn !px-2" onClick={() => nav('/dashboard')} aria-label="Back to dashboard">
            <ArrowLeft size={18} />
          </button>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-muted">Report preview</p>
            <p className="font-semibold">{report.business.name}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          {isDemo ? (
            <button className="btn-secondary btn" onClick={copyDemo}>
              <Copy size={16} /> Copy &amp; edit
            </button>
          ) : (
            <Link className="btn-secondary btn" to={`/edit/${report.id}`}>
              <Pencil size={16} /> Edit
            </Link>
          )}
          <button className="btn-secondary btn" onClick={() => window.print()}>
            <Printer size={16} /> Print
          </button>
          <button className="btn-secondary btn" onClick={() => downloadCsv(report)}>
            <FileSpreadsheet size={16} /> CSV
          </button>
          <button className="btn-primary btn" onClick={pdf} disabled={busy} data-testid="download-pdf">
            {busy ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} Download PDF
          </button>
        </div>
      </div>
      <div className="no-print mb-4 flex flex-wrap items-center gap-2 text-sm">
        <span className="text-muted">PDF layout:</span>
        {(['portrait', 'landscape'] as const).map((o) => (
          <button key={o} onClick={() => setOrientation(o)} className={`rounded-full border px-3 py-1 capitalize ${report.custom.orientation === o ? 'border-ink bg-ink text-white' : 'border-line bg-white'}`}>
            A4 {o}
          </button>
        ))}
        {msg && <span className="ml-auto text-xs text-muted" role="status">{msg}</span>}
      </div>
      <div className="print-area overflow-hidden rounded-xl border border-line shadow-sm">
        <ReportView report={report} />
      </div>
    </div>
  );
}
