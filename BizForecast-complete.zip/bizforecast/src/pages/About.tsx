import { useEffect, useState } from 'react';
import { Download } from 'lucide-react';
import { DISCLAIMER } from '../components/report/ReportView';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
}

export default function About() {
  const [installEvt, setInstallEvt] = useState<BeforeInstallPromptEvent | null>(null);
  const standalone = typeof window !== 'undefined' && window.matchMedia?.('(display-mode: standalone)').matches;

  useEffect(() => {
    const h = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e as BeforeInstallPromptEvent);
    };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="text-3xl font-bold tracking-tight">About BizForecast</h1>
      <p className="mt-3 text-ink-soft">
        BizForecast helps business owners create clear, professional financial projection reports. Enter your figures, choose the metrics that matter, and download a print-ready PDF.
      </p>

      <h2 className="mt-8 text-lg font-bold">Install the app</h2>
      {standalone ? (
        <p className="mt-2 text-sm text-ink-soft">BizForecast is installed on this device and works offline.</p>
      ) : (
        <>
          <p className="mt-2 text-sm text-ink-soft">
            BizForecast can be installed like an app and used without internet. On Android (Chrome), open the browser menu and choose <strong>Install app</strong> or <strong>Add to Home screen</strong>. On iPhone (Safari), tap Share → <strong>Add to Home Screen</strong>. On a computer, use the install icon in the address bar.
          </p>
          {installEvt && (
            <button className="btn-primary btn mt-3" onClick={() => installEvt.prompt()}>
              <Download size={16} /> Install BizForecast
            </button>
          )}
        </>
      )}

      <h2 className="mt-8 text-lg font-bold">Your privacy</h2>
      <p className="mt-2 text-sm text-ink-soft">
        There is no account and no server. Your reports are stored in this browser's local storage on this device only, and PDFs and CSV files are created on your device. Clearing your browser data will delete saved reports, so download PDFs or CSVs you want to keep.
      </p>

      <h2 className="mt-8 text-lg font-bold">How figures are calculated</h2>
      <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-ink-soft">
        <li>Growth % = (projected − previous) ÷ previous × 100. It is shown as “n/a” when the previous value is zero or negative, because a percentage would be misleading.</li>
        <li>Profit = revenue − expenses, unless you enter your own profit figure.</li>
        <li>Profit margin = profit ÷ revenue × 100 (only when revenue is above zero).</li>
        <li>Changes in rates such as churn or retention are shown in percentage points (pts).</li>
        <li>Empty boxes are never treated as zero.</li>
      </ul>

      <h2 className="mt-8 text-lg font-bold">Disclaimer</h2>
      <p className="mt-2 text-sm text-ink-soft">{DISCLAIMER}</p>

      <div className="mt-10 flex items-center gap-3 border-t border-line pt-6">
        <img src="./rk-logo.png" alt="RK Digitals logo" width={36} height={36} className="h-9 w-9" />
        <div className="text-sm">
          <p className="font-semibold">Developed and published by RK Digitals</p>
          <p className="text-xs text-muted">BizForecast version {__APP_VERSION__}</p>
        </div>
      </div>
    </div>
  );
}
