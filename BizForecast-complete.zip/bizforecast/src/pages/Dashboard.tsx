import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Eye, FileText, FlaskConical, Pencil, Plus, Trash2 } from 'lucide-react';
import type { Report } from '../types';
import { storage } from '../lib/storage';
import { derive, fmtChange, fmtDate, fmtMoney } from '../lib/calc';

function useReports() {
  const [list, setList] = useState<Report[]>(() => storage.list());
  useEffect(() => {
    const refresh = () => setList(storage.list());
    window.addEventListener('bizforecast:reports', refresh);
    window.addEventListener('storage', refresh);
    return () => {
      window.removeEventListener('bizforecast:reports', refresh);
      window.removeEventListener('storage', refresh);
    };
  }, []);
  return list;
}

function ConfirmDelete({ report, onCancel, onConfirm }: { report: Report; onCancel: () => void; onConfirm: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-4 sm:items-center" role="dialog" aria-modal="true" aria-labelledby="del-title">
      <div className="w-full max-w-sm rounded-2xl bg-white p-5 shadow-xl">
        <h2 id="del-title" className="text-lg font-bold">
          Delete this report?
        </h2>
        <p className="mt-1 text-sm text-muted">
          “{report.business.name || 'Untitled'}” ({report.business.reportingYear}) will be permanently removed from this device. This cannot be undone.
        </p>
        <div className="mt-5 flex justify-end gap-2">
          <button className="btn-secondary btn" onClick={onCancel} autoFocus>
            Cancel
          </button>
          <button className="btn-danger btn" onClick={onConfirm}>
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const reports = useReports();
  const [toDelete, setToDelete] = useState<Report | null>(null);
  const recent = reports.slice(0, 3);

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:py-10">
      <section className="flex flex-col gap-4 rounded-2xl border border-line bg-white p-6 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Welcome to BizForecast</h1>
          <p className="mt-1 text-sm text-muted">
            {reports.length ? `You have ${reports.length} saved ${reports.length === 1 ? 'report' : 'reports'} on this device.` : 'Create your first financial projection report in a few minutes.'}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Link to="/report/sample" className="btn-secondary btn">
            <FlaskConical size={16} /> View demo report
          </Link>
          <Link to="/new" className="btn-primary btn">
            <Plus size={16} /> Create new report
          </Link>
        </div>
      </section>

      {reports.length === 0 ? (
        <section className="mt-8 rounded-2xl border border-dashed border-ink/20 bg-white p-10 text-center">
          <FileText className="mx-auto text-muted" size={32} />
          <p className="mt-3 font-semibold">No reports yet</p>
          <p className="mt-1 text-sm text-muted">Reports you create are saved here automatically.</p>
        </section>
      ) : (
        <>
          <h2 className="mb-3 mt-8 text-sm font-semibold uppercase tracking-wider text-muted">Recently updated</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {recent.map((r) => {
              const d = derive(r);
              return (
                <article key={r.id} className="card flex flex-col p-5" data-testid="recent-card">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate font-semibold">{r.business.name || 'Untitled'}</p>
                      <p className="text-xs text-muted">
                        Projection {r.business.reportingYear}
                        {r.business.category && ` · ${r.business.category}`}
                      </p>
                    </div>
                    {r.isSample && <span className="rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-900">DEMO</span>}
                  </div>
                  <div className="mt-4 flex-1">
                    <p className="text-xs text-muted">Projected revenue</p>
                    <p className="text-2xl font-bold tracking-tight">{fmtMoney(d.revenue.proj, r.business.currency)}</p>
                    <p className="text-xs text-muted">Growth {fmtChange(d.revenue.change)}</p>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Link to={`/report/${r.id}`} className="btn-primary btn flex-1 !py-2">
                      <Eye size={15} /> Preview
                    </Link>
                    <Link to={`/edit/${r.id}`} className="btn-secondary btn !py-2" aria-label="Edit">
                      <Pencil size={15} />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>

          <h2 className="mb-3 mt-10 text-sm font-semibold uppercase tracking-wider text-muted">All saved reports</h2>
          <div className="card overflow-hidden">
            <ul className="divide-y divide-line">
              {reports.map((r) => (
                <li key={r.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center" data-testid="report-row">
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">
                      {r.business.name || 'Untitled'} {r.isSample && <span className="ml-1 rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-900">DEMO</span>}
                    </p>
                    <p className="text-xs text-muted">
                      Reporting year {r.business.reportingYear} · Created {fmtDate(r.createdAt.slice(0, 10))} · Updated {fmtDate(r.updatedAt.slice(0, 10))}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Link to={`/report/${r.id}`} className="btn-secondary btn !py-2">
                      <Eye size={15} /> Preview
                    </Link>
                    <Link to={`/edit/${r.id}`} className="btn-secondary btn !py-2">
                      <Pencil size={15} /> Edit
                    </Link>
                    <button className="btn-ghost btn !py-2 text-red-600" onClick={() => setToDelete(r)} aria-label={`Delete ${r.business.name}`}>
                      <Trash2 size={15} />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </>
      )}

      {toDelete && (
        <ConfirmDelete
          report={toDelete}
          onCancel={() => setToDelete(null)}
          onConfirm={() => {
            storage.remove(toDelete.id);
            setToDelete(null);
          }}
        />
      )}
    </div>
  );
}
