import { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import type { Customisation, Headings, Report, ThemeId } from '../../types';
import { Field, Toggle } from '../../components/form';
import { THEMES } from '../../lib/defaults';
import { autoSummary } from '../../lib/summary';

const HEADING_LABELS: Record<keyof Headings, string> = {
  title: 'Report title',
  summary: 'Summary heading',
  highlights: 'Highlights heading',
  comparison: 'Financial chart heading',
  customers: 'Customer chart heading',
  performance: 'Performance tables heading',
  growth: 'Growth & retention heading',
  custom: 'Custom KPIs heading',
  assumptions: 'Assumptions heading',
};

export default function StepCustomise({
  report,
  set,
  setYear,
  errors,
}: {
  report: Report;
  set: (p: Partial<Customisation>) => void;
  setYear: (y: number) => void;
  errors: Record<string, string>;
}) {
  const c = report.custom;
  const [showHeadings, setShowHeadings] = useState(false);
  const auto = autoSummary(report);

  return (
    <div className="space-y-6">
      <section>
        <p className="mb-2 text-sm font-semibold">Executive summary</p>
        <textarea
          aria-label="Executive summary"
          rows={5}
          maxLength={1200}
          className="input resize-y"
          placeholder={auto}
          value={c.executiveSummary}
          onChange={(e) => set({ executiveSummary: e.target.value })}
        />
        <div className="mt-1 flex flex-wrap items-center justify-between gap-2 text-xs text-muted">
          <span>{c.executiveSummary.trim() ? 'Your own text will be used.' : 'Leave empty to use the automatic summary shown in grey (written only from your figures).'}</span>
          <div className="flex gap-2">
            {!c.executiveSummary.trim() && (
              <button type="button" className="font-semibold text-ink underline" onClick={() => set({ executiveSummary: auto })}>
                Edit the automatic text
              </button>
            )}
            {c.executiveSummary.trim() && (
              <button type="button" className="font-semibold text-ink underline" onClick={() => set({ executiveSummary: '' })}>
                Use automatic summary
              </button>
            )}
          </div>
        </div>
      </section>

      <section>
        <p className="mb-2 text-sm font-semibold">Key figures to highlight</p>
        <div className="grid gap-2 sm:grid-cols-2">
          {(
            [
              ['projectedRevenue', 'Projected revenue'],
              ['projectedProfit', 'Projected profit'],
              ['revenueGrowth', 'Revenue growth %'],
              ['profitMargin', 'Profit margin %'],
              ['projectedExpenses', 'Projected expenses'],
              ['profitGrowth', 'Profit growth %'],
            ] as const
          ).map(([k, l]) => (
            <Toggle key={k} label={l} checked={c.kpis[k]} onChange={(v) => set({ kpis: { ...c.kpis, [k]: v } })} />
          ))}
        </div>
      </section>

      <section>
        <p className="mb-2 text-sm font-semibold">Charts and tables to include</p>
        <p className="mb-2 text-xs text-muted">Sections without data are hidden automatically.</p>
        <div className="grid gap-2 sm:grid-cols-2">
          <Toggle label="Financial comparison chart" help="Revenue, expenses and profit — last year vs projection" checked={c.charts.financialComparison} onChange={(v) => set({ charts: { ...c.charts, financialComparison: v } })} />
          <Toggle label="Customer comparison chart" help="Registered, premium, business, new customers" checked={c.charts.customerComparison} onChange={(v) => set({ charts: { ...c.charts, customerComparison: v } })} />
          <Toggle label="Performance tables" help="Traffic, sales, rates and other metrics" checked={c.charts.metricsTable} onChange={(v) => set({ charts: { ...c.charts, metricsTable: v } })} />
          <Toggle label="Retention & rate donut charts" help="Retention, churn, conversion, profit margin" checked={c.charts.rateDonuts} onChange={(v) => set({ charts: { ...c.charts, rateDonuts: v } })} />
        </div>
      </section>

      <section className="grid gap-5 sm:grid-cols-2">
        <div>
          <p className="mb-2 text-sm font-semibold">Theme</p>
          <div className="space-y-2">
            {(Object.keys(THEMES) as ThemeId[]).map((id) => (
              <label key={id} className={`flex cursor-pointer items-center gap-3 rounded-lg border p-3 ${c.theme === id ? 'border-ink' : 'border-line'} bg-white`}>
                <input type="radio" name="theme" checked={c.theme === id} onChange={() => set({ theme: id })} className="accent-[#171a1f]" />
                <span className="flex gap-1">
                  <i className="h-4 w-6 rounded-sm" style={{ background: THEMES[id].prev }} />
                  <i className="h-4 w-6 rounded-sm" style={{ background: THEMES[id].proj }} />
                </span>
                <span className="text-sm">{THEMES[id].name}</span>
              </label>
            ))}
          </div>
        </div>
        <div className="space-y-5">
          <Field label="Projection year" htmlFor="cyear" error={errors.reportingYear}>
            <input id="cyear" type="number" inputMode="numeric" className={`input ${errors.reportingYear ? 'input-error' : ''}`} value={Number.isFinite(report.business.reportingYear) ? report.business.reportingYear : ''} onChange={(e) => setYear(e.target.value === '' ? NaN : Number(e.target.value))} />
          </Field>
          <div>
            <p className="mb-2 text-sm font-semibold">PDF page layout</p>
            <div className="flex gap-2">
              {(['portrait', 'landscape'] as const).map((o) => (
                <label key={o} className={`flex flex-1 cursor-pointer items-center gap-2 rounded-lg border bg-white p-3 text-sm capitalize ${c.orientation === o ? 'border-ink' : 'border-line'}`}>
                  <input type="radio" name="orientation" checked={c.orientation === o} onChange={() => set({ orientation: o })} className="accent-[#171a1f]" />A4 {o}
                </label>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section>
        <button type="button" className="flex w-full items-center justify-between rounded-lg border border-line bg-white px-4 py-3 text-sm font-semibold" onClick={() => setShowHeadings((s) => !s)} aria-expanded={showHeadings}>
          Edit section headings
          <ChevronDown size={16} className={`transition ${showHeadings ? 'rotate-180' : ''}`} />
        </button>
        {showHeadings && (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {(Object.keys(HEADING_LABELS) as (keyof Headings)[]).map((k) => (
              <Field key={k} label={HEADING_LABELS[k]} htmlFor={`h-${k}`} error={errors[`h.${k}`]}>
                <input id={`h-${k}`} className={`input ${errors[`h.${k}`] ? 'input-error' : ''}`} maxLength={60} value={c.headings[k]} onChange={(e) => set({ headings: { ...c.headings, [k]: e.target.value } })} />
              </Field>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
