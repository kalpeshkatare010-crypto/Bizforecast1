import type { BusinessInfo } from '../../types';
import { Field } from '../../components/form';
import { BUSINESS_CATEGORIES } from '../../lib/defaults';
import { CURRENCIES } from '../../lib/calc';

export default function StepBusiness({ b, set, errors }: { b: BusinessInfo; set: (p: Partial<BusinessInfo>) => void; errors: Record<string, string> }) {
  return (
    <div className="grid gap-5 sm:grid-cols-2">
      <div className="sm:col-span-2">
        <Field label="Business name" htmlFor="bname" error={errors.name} help="As you want it to appear on the report.">
          <input id="bname" className={`input ${errors.name ? 'input-error' : ''}`} value={b.name} maxLength={80} placeholder="e.g. Sunrise Bakery" onChange={(e) => set({ name: e.target.value })} />
        </Field>
      </div>
      <Field label="Business category" htmlFor="bcat" optional help="Pick the closest match, or type your own.">
        <input id="bcat" list="cats" className="input" value={b.category} placeholder="e.g. Restaurant / Café" onChange={(e) => set({ category: e.target.value })} maxLength={50} />
        <datalist id="cats">
          {BUSINESS_CATEGORIES.map((c) => (
            <option key={c} value={c} />
          ))}
        </datalist>
      </Field>
      <Field label="Currency" htmlFor="bcur">
        <select id="bcur" className="input" value={b.currency} onChange={(e) => set({ currency: e.target.value })}>
          {CURRENCIES.map((c) => (
            <option key={c.code} value={c.code}>
              {c.code} — {c.label}
            </option>
          ))}
        </select>
      </Field>
      <div className="sm:col-span-2">
        <Field label="Short business description" htmlFor="bdesc" optional help="One or two sentences about what you do. Used for your reference; it is not added to the report automatically.">
          <textarea id="bdesc" rows={2} className="input resize-y" value={b.description} maxLength={400} placeholder="e.g. A neighbourhood bakery selling fresh bread, cakes and catering orders." onChange={(e) => set({ description: e.target.value })} />
        </Field>
      </div>
      <Field label="Projection year" htmlFor="byear" error={errors.reportingYear} help={`The year you are forecasting. Last year's figures will be labelled ${b.reportingYear - 1}.`}>
        <input
          id="byear"
          type="number"
          inputMode="numeric"
          className={`input ${errors.reportingYear ? 'input-error' : ''}`}
          value={Number.isFinite(b.reportingYear) ? b.reportingYear : ''}
          onChange={(e) => set({ reportingYear: e.target.value === '' ? NaN : Number(e.target.value) })}
        />
      </Field>
      <Field label="Financial year label" htmlFor="bfy" optional help="How your financial year is written, e.g. FY 2026–27 or Jan–Dec 2027.">
        <input id="bfy" className="input" value={b.financialYear} maxLength={40} onChange={(e) => set({ financialYear: e.target.value })} />
      </Field>
      <Field label="Report preparation date" htmlFor="bdate" error={errors.preparedDate}>
        <input id="bdate" type="date" className={`input ${errors.preparedDate ? 'input-error' : ''}`} value={b.preparedDate} onChange={(e) => set({ preparedDate: e.target.value })} />
      </Field>
    </div>
  );
}
