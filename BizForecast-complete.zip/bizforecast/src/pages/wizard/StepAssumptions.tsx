import { Plus, Trash2, Wand2 } from 'lucide-react';
import type { Assumptions, Financials, Num, Report } from '../../types';
import { Badge, Field, NumberInput, Tip } from '../../components/form';
import { applyGrowth, derive, fmtChange, fmtMoney, has, metricChange } from '../../lib/calc';
import { uid } from '../../lib/defaults';

export default function StepAssumptions({
  report,
  set,
  setFin,
  reporter,
}: {
  report: Report;
  set: (p: Partial<Assumptions>) => void;
  setFin: (p: Partial<Financials>) => void;
  reporter: (k: string) => (e: string | null) => void;
}) {
  const a = report.assumptions;
  const f = report.financials;
  const d = derive(report);
  const cur = report.business.currency;
  const reg = report.metrics.find((m) => m.key === 'registered');
  const regChange = reg ? metricChange(reg) : null;

  const item = (
    key: 'revenueGrowth' | 'expenseGrowth' | 'customerGrowth' | 'retention',
    label: string,
    help: string,
    tip: string,
    calc: string | null,
    apply?: { base: Num; target: keyof Financials; what: string },
  ) => {
    const projected = apply ? applyGrowth(apply.base, a[key]) : null;
    return (
      <div className="rounded-xl border border-line bg-white p-4">
        <Field label={label} htmlFor={key} optional help={help} badge={<Tip>{tip}</Tip>}>
          <div className="max-w-56">
            <NumberInput id={key} suffix="%" value={a[key]} onChange={(v) => set({ [key]: v })} min={key === 'retention' ? 0 : -100} max={key === 'retention' ? 100 : 10000} placeholder="e.g. 10" onValidity={reporter(`as.${key}`)} />
          </div>
        </Field>
        <div className="mt-3 flex flex-wrap items-center gap-2 text-xs">
          {calc !== null && (
            <span className="inline-flex items-center gap-1.5">
              <Badge kind="calc">Calculated</Badge> From your figures: <strong>{calc}</strong>
            </span>
          )}
          {apply && projected !== null && (
            <button type="button" className="btn-secondary btn !px-2.5 !py-1.5 text-xs" onClick={() => setFin({ [apply.target]: projected } as Partial<Financials>)}>
              <Wand2 size={14} /> Set projected {apply.what} to {fmtMoney(projected, cur)}
            </button>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2 rounded-lg bg-canvas p-3 text-xs text-ink-soft">
        <Badge kind="assume">Your assumption</Badge> = what you expect to happen.
        <Badge kind="calc">Calculated</Badge> = worked out from the figures you entered. Both are shown separately on the report.
      </div>
      {item(
        'revenueGrowth',
        'Expected revenue growth',
        'How much you expect sales to grow (use a negative number for a decline).',
        'Growth of 10% means you expect revenue to be 10% higher than last year.',
        d.revenue.change.kind === 'pct' ? fmtChange(d.revenue.change) : null,
        has(f.prevRevenue) ? { base: f.prevRevenue, target: 'projRevenue', what: 'revenue' } : undefined,
      )}
      {item(
        'expenseGrowth',
        'Expected expense growth',
        'How much you expect costs to rise or fall.',
        'If costs were 1,00,000 and you expect 5% growth, projected expenses would be 1,05,000.',
        d.expenses.change.kind === 'pct' ? fmtChange(d.expenses.change) : null,
        has(f.prevExpenses) ? { base: f.prevExpenses, target: 'projExpenses', what: 'expenses' } : undefined,
      )}
      {item('customerGrowth', 'Expected customer growth', 'How much you expect your customer base to grow.', 'Compared with your registered customer numbers, if you added them in the previous step.', regChange && regChange.kind === 'pct' ? fmtChange(regChange) : null)}
      {item('retention', 'Expected customer retention', 'Out of every 100 customers, how many you expect to keep.', 'Retention of 70% means 70 out of 100 customers keep buying from you during the year. Used for the retention chart if you did not add a retention metric.', null)}

      <div className="rounded-xl border border-line bg-white p-4">
        <p className="font-semibold">Other assumptions</p>
        <p className="mb-3 text-xs text-muted">Explain what your projection depends on — e.g. "New branch opens in June", "Price rise of 5% from April".</p>
        <div className="space-y-2">
          {a.notes.map((n, i) => (
            <div key={n.id} className="grid gap-2 sm:grid-cols-[1fr_2fr_auto]">
              <input aria-label="Assumption title" className="input" placeholder="Title, e.g. Pricing" value={n.label} maxLength={60} onChange={(e) => set({ notes: a.notes.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) })} />
              <input aria-label="Assumption detail" className="input" placeholder="Detail, e.g. 5% price increase from April" value={n.value} maxLength={200} onChange={(e) => set({ notes: a.notes.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)) })} />
              <button type="button" className="btn-ghost btn" aria-label="Remove assumption" onClick={() => set({ notes: a.notes.filter((_, j) => j !== i) })}>
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
        <button type="button" className="btn-secondary btn mt-3" onClick={() => set({ notes: [...a.notes, { id: uid(), label: '', value: '' }] })}>
          <Plus size={16} /> Add assumption
        </button>
      </div>
    </div>
  );
}
