import { useState } from 'react';
import { Check, Plus, Trash2 } from 'lucide-react';
import type { Metric, MetricUnit, Report } from '../../types';
import { Field, NumberInput } from '../../components/form';
import { PRESET_METRICS, metricFromPreset, uid } from '../../lib/defaults';
import { currencySymbol, fmtChange, metricChange } from '../../lib/calc';

const UNIT_LABEL: Record<MetricUnit, string> = { number: 'Number', percent: 'Percentage (%)', currency: 'Money amount' };

function MetricCard({
  m,
  report,
  onChange,
  onRemove,
  reporter,
  error,
}: {
  m: Metric;
  report: Report;
  onChange: (m: Metric) => void;
  onRemove: () => void;
  reporter: (k: string) => (e: string | null) => void;
  error?: string;
}) {
  const py = report.business.reportingYear - 1;
  const ny = report.business.reportingYear;
  const preset = PRESET_METRICS.find((p) => p.key === m.key);
  const pct = m.unit === 'percent';
  const props = {
    suffix: pct ? '%' : undefined,
    prefix: m.unit === 'currency' ? currencySymbol(report.business.currency) : undefined,
    min: 0,
    max: pct ? 100 : undefined,
  };
  const c = metricChange(m);
  return (
    <div className="rounded-xl border border-line bg-white p-4" data-testid="metric-card">
      <div className="mb-3 flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          {m.custom ? (
            <div className="grid gap-2 sm:grid-cols-[1fr_180px]">
              <input aria-label="Metric name" className={`input ${error ? 'input-error' : ''}`} value={m.label} placeholder="Metric name, e.g. Average order value" maxLength={60} onChange={(e) => onChange({ ...m, label: e.target.value })} />
              <select aria-label="Metric type" className="input" value={m.unit} onChange={(e) => onChange({ ...m, unit: e.target.value as MetricUnit })}>
                {(Object.keys(UNIT_LABEL) as MetricUnit[]).map((u) => (
                  <option key={u} value={u}>
                    {UNIT_LABEL[u]}
                  </option>
                ))}
              </select>
              {error && <p className="text-xs font-medium text-red-600 sm:col-span-2">{error}</p>}
            </div>
          ) : (
            <>
              <p className="font-semibold">{m.label}</p>
              {preset && <p className="text-xs text-muted">{preset.help}</p>}
            </>
          )}
        </div>
        <button type="button" onClick={onRemove} className="btn-ghost btn !p-2" aria-label={`Remove ${m.label || 'metric'}`}>
          <Trash2 size={16} />
        </button>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label={`${py}`}>
          <NumberInput {...props} ariaLabel={`${m.label} ${py}`} value={m.prev} onChange={(v) => onChange({ ...m, prev: v })} placeholder={preset ? `e.g. ${preset.example}` : ''} onValidity={reporter(`met.${m.id}.p`)} />
        </Field>
        <Field label={`${ny} (projected)`}>
          <NumberInput {...props} ariaLabel={`${m.label} ${ny}`} value={m.proj} onChange={(v) => onChange({ ...m, proj: v })} placeholder={preset ? `e.g. ${preset.example}` : ''} onValidity={reporter(`met.${m.id}.n`)} />
        </Field>
        <div className="flex flex-col justify-end pb-2 text-sm">
          <span className="text-xs text-muted">{pct ? 'Change (points)' : 'Change'}</span>
          <span className="font-semibold tabular-nums">{fmtChange(c)}</span>
        </div>
      </div>
    </div>
  );
}

export default function StepMetrics({
  report,
  setMetrics,
  reporter,
  clear,
  errors,
}: {
  report: Report;
  setMetrics: (m: Metric[]) => void;
  reporter: (k: string) => (e: string | null) => void;
  clear: (prefix: string) => void;
  errors: Record<string, string>;
}) {
  const [customUnit, setCustomUnit] = useState<MetricUnit>('number');
  const metrics = report.metrics;
  const active = new Set(metrics.filter((m) => !m.custom).map((m) => m.key));

  const togglePreset = (key: string) => {
    if (active.has(key)) {
      const m = metrics.find((x) => x.key === key && !x.custom);
      if (m) clear(`met.${m.id}`);
      setMetrics(metrics.filter((x) => !(x.key === key && !x.custom)));
    } else {
      setMetrics([...metrics, metricFromPreset(PRESET_METRICS.find((p) => p.key === key)!)]);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="mb-1 text-sm font-semibold">Choose the metrics that matter to your business</p>
        <p className="mb-3 text-xs text-muted">All optional. Tap to add — only the ones you add will appear on the report. Skip this step if none apply.</p>
        <div className="flex flex-wrap gap-2">
          {PRESET_METRICS.map((p) => {
            const on = active.has(p.key);
            return (
              <button
                key={p.key}
                type="button"
                aria-pressed={on}
                onClick={() => togglePreset(p.key)}
                className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-sm transition ${on ? 'border-ink bg-ink text-white' : 'border-line bg-white hover:border-ink/40'}`}
              >
                {on ? <Check size={14} /> : <Plus size={14} />} {p.label}
              </button>
            );
          })}
        </div>
      </div>

      {metrics.length > 0 && (
        <div className="space-y-3">
          {metrics.map((m) => (
            <MetricCard
              key={m.id}
              m={m}
              report={report}
              reporter={reporter}
              error={errors[`met.${m.id}.label`]}
              onChange={(nm) => setMetrics(metrics.map((x) => (x.id === m.id ? nm : x)))}
              onRemove={() => {
                clear(`met.${m.id}`);
                setMetrics(metrics.filter((x) => x.id !== m.id));
              }}
            />
          ))}
        </div>
      )}

      <div className="rounded-xl border border-dashed border-ink/25 bg-white p-4">
        <p className="font-semibold">Create your own metric</p>
        <p className="mb-3 text-xs text-muted">Anything you track — average order value, students enrolled, tables served per day, repeat orders…</p>
        <div className="flex flex-col gap-2 sm:flex-row">
          <select aria-label="New metric type" className="input sm:w-56" value={customUnit} onChange={(e) => setCustomUnit(e.target.value as MetricUnit)}>
            {(Object.keys(UNIT_LABEL) as MetricUnit[]).map((u) => (
              <option key={u} value={u}>
                {UNIT_LABEL[u]}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="btn-secondary btn"
            onClick={() => setMetrics([...metrics, { id: uid(), key: 'custom', label: '', unit: customUnit, group: 'other', prev: null, proj: null, custom: true }])}
          >
            <Plus size={16} /> Add custom metric
          </button>
        </div>
      </div>
    </div>
  );
}
