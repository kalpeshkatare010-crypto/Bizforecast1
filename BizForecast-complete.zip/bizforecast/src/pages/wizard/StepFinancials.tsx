import { Plus, Trash2, AlertTriangle } from 'lucide-react';
import type { Financials, Num } from '../../types';
import { Badge, Field, NumberInput, Tip } from '../../components/form';
import { currencySymbol, derive, effectiveProfit, fmtChange, fmtMoney, fmtPct, has, profitMismatch, changeHint } from '../../lib/calc';
import { uid } from '../../lib/defaults';
import type { Report } from '../../types';

export default function StepFinancials({
  report,
  set,
  reporter,
  errors,
}: {
  report: Report;
  set: (p: Partial<Financials>) => void;
  reporter: (k: string) => (e: string | null) => void;
  errors: Record<string, string>;
}) {
  const f = report.financials;
  const cur = report.business.currency;
  const sym = currencySymbol(cur);
  const py = report.business.reportingYear - 1;
  const ny = report.business.reportingYear;
  const d = derive(report);

  const row = (label: string, help: string, prevKey: keyof Financials, projKey: keyof Financials, opts: { allowNegative?: boolean; exPrev: string; exProj: string; tip?: string }) => (
    <div className="rounded-xl border border-line bg-white p-4">
      <div className="mb-3 flex items-center gap-1.5">
        <p className="font-semibold">{label}</p>
        {opts.tip && <Tip>{opts.tip}</Tip>}
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={`${py} (actual)`} htmlFor={`${String(prevKey)}`} help={help}>
          <NumberInput
            id={String(prevKey)}
            prefix={sym}
            value={f[prevKey] as Num}
            onChange={(v) => set({ [prevKey]: v } as Partial<Financials>)}
            placeholder={`e.g. ${opts.exPrev}`}
            min={opts.allowNegative ? undefined : 0}
            onValidity={reporter(`fin.${String(prevKey)}`)}
          />
        </Field>
        <Field label={`${ny} (projected)`} htmlFor={`${String(projKey)}`}>
          <NumberInput
            id={String(projKey)}
            prefix={sym}
            value={f[projKey] as Num}
            onChange={(v) => set({ [projKey]: v } as Partial<Financials>)}
            placeholder={`e.g. ${opts.exProj}`}
            min={opts.allowNegative ? undefined : 0}
            onValidity={reporter(`fin.${String(projKey)}`)}
          />
        </Field>
      </div>
    </div>
  );

  const prevCalc = effectiveProfit(f.prevProfit, f.prevRevenue, f.prevExpenses);
  const projCalc = effectiveProfit(f.projProfit, f.projRevenue, f.projExpenses);
  const mPrev = profitMismatch(f.prevProfit, f.prevRevenue, f.prevExpenses);
  const mProj = profitMismatch(f.projProfit, f.projRevenue, f.projExpenses);

  return (
    <div className="space-y-4">
      {errors['fin.required'] && (
        <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm font-medium text-red-700">
          {errors['fin.required']}
        </p>
      )}
      {row('Revenue (sales income)', 'Total money received from sales.', 'prevRevenue', 'projRevenue', { exPrev: '12,00,000', exProj: '14,00,000', tip: 'Revenue is all the money your business earns from selling products or services, before any costs are taken out.' })}
      {row('Expenses (total costs)', 'Rent, salaries, materials, bills, etc.', 'prevExpenses', 'projExpenses', { exPrev: '9,50,000', exProj: '10,60,000', tip: 'Expenses are all the costs of running the business: rent, wages, stock, utilities, marketing, loan interest and so on.' })}

      <div className="rounded-xl border border-line bg-white p-4">
        <div className="mb-1 flex items-center gap-1.5">
          <p className="font-semibold">Profit</p>
          <Tip>Profit = Revenue − Expenses. Leave these boxes empty and BizForecast calculates it for you. Enter a figure only if your accountant's profit is different (for example after tax).</Tip>
        </div>
        <p className="mb-3 text-xs text-muted">Optional — leave blank to calculate automatically as revenue minus expenses. A loss can be entered as a negative number.</p>
        <div className="grid gap-3 sm:grid-cols-2">
          {(
            [
              ['prevProfit', `${py} (actual)`, prevCalc, mPrev],
              ['projProfit', `${ny} (projected)`, projCalc, mProj],
            ] as const
          ).map(([key, lab, calc, mismatch]) => (
            <Field key={key} label={lab} htmlFor={key} badge={calc.source === 'calculated' ? <Badge kind="calc">Calculated</Badge> : undefined}>
              <NumberInput
                id={key}
                prefix={sym}
                value={f[key]}
                onChange={(v) => set({ [key]: v })}
                placeholder={calc.source === 'calculated' ? `Auto: ${fmtMoney(calc.value, cur)}` : 'Leave blank to calculate'}
                onValidity={reporter(`fin.${key}`)}
              />
              {mismatch !== null && (
                <p className="mt-1 flex items-start gap-1 text-xs text-amber-700">
                  <AlertTriangle size={13} className="mt-px shrink-0" /> Revenue − expenses = {fmtMoney(mismatch, cur)}. Your figure will be used; please double-check it.
                </p>
              )}
            </Field>
          ))}
        </div>
      </div>

      {/* Calculated summary */}
      <div className="rounded-xl border border-sky-200 bg-sky-50/60 p-4">
        <div className="mb-3 flex items-center gap-2">
          <Badge kind="calc">Calculated automatically</Badge>
        </div>
        <dl className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          {(
            [
              ['Revenue growth', fmtChange(d.revenue.change), changeHint(d.revenue.change)],
              ['Expense growth', fmtChange(d.expenses.change), changeHint(d.expenses.change)],
              ['Profit growth', fmtChange(d.profit.change), changeHint(d.profit.change)],
              [`Profit margin ${ny}`, fmtPct(d.marginProj), d.marginProj === null && has(d.profit.proj.value) ? 'Needs projected revenue above zero.' : 'Profit as a share of revenue.'],
            ] as const
          ).map(([k, v, h]) => (
            <div key={k}>
              <dt className="text-xs text-muted">{k}</dt>
              <dd className="text-lg font-bold tabular-nums">{v}</dd>
              {h && <p className="text-[11px] leading-snug text-muted">{h}</p>}
            </div>
          ))}
        </dl>
      </div>

      {/* Extra figures */}
      <div className="rounded-xl border border-line bg-white p-4">
        <p className="font-semibold">Other financial figures</p>
        <p className="mb-3 text-xs text-muted">Optional — e.g. loan repayments, investment, cash in bank. Shown in a separate table.</p>
        <div className="space-y-3">
          {f.extra.map((x, i) => (
            <div key={x.id} className="grid items-start gap-2 rounded-lg bg-canvas p-3 sm:grid-cols-[1.4fr_1fr_1fr_auto]">
              <input
                aria-label="Figure name"
                className="input"
                placeholder="Name, e.g. Equipment investment"
                value={x.label}
                maxLength={60}
                onChange={(e) => set({ extra: f.extra.map((y, j) => (j === i ? { ...y, label: e.target.value } : y)) })}
              />
              <NumberInput ariaLabel={`${x.label || 'Figure'} ${py}`} prefix={sym} value={x.prev} placeholder={String(py)} onChange={(v) => set({ extra: f.extra.map((y, j) => (j === i ? { ...y, prev: v } : y)) })} onValidity={reporter(`fin.extra.${x.id}.p`)} />
              <NumberInput ariaLabel={`${x.label || 'Figure'} ${ny}`} prefix={sym} value={x.proj} placeholder={String(ny)} onChange={(v) => set({ extra: f.extra.map((y, j) => (j === i ? { ...y, proj: v } : y)) })} onValidity={reporter(`fin.extra.${x.id}.n`)} />
              <button type="button" className="btn-ghost btn" aria-label="Remove figure" onClick={() => set({ extra: f.extra.filter((_, j) => j !== i) })}>
                <Trash2 size={16} />
              </button>
              {errors[`fin.extra.${x.id}.label`] && <p className="text-xs text-red-600 sm:col-span-4">{errors[`fin.extra.${x.id}.label`]}</p>}
            </div>
          ))}
        </div>
        <button type="button" className="btn-secondary btn mt-3" onClick={() => set({ extra: [...f.extra, { id: uid(), label: '', prev: null, proj: null }] })}>
          <Plus size={16} /> Add a figure
        </button>
      </div>
    </div>
  );
}
