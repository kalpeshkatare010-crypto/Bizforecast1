import { Link } from 'react-router-dom';
import { ArrowRight, BarChart3, Calculator, Download, Layers, Lock, WifiOff } from 'lucide-react';
import { useMemo } from 'react';
import ReportView from '../components/report/ReportView';
import { sampleReport } from '../lib/sample';
import { BizMark } from '../components/Brand';

const FEATURES = [
  { icon: Calculator, title: 'Accurate calculations', text: 'Growth, profit and margin are calculated for you — with no misleading percentages and no made-up numbers.' },
  { icon: BarChart3, title: 'Professional charts', text: 'Clean bar charts, donut charts and tables built from your own figures.' },
  { icon: Layers, title: 'Any kind of business', text: 'Shops, cafés, agencies, freelancers, manufacturers, schools — pick only the metrics that apply.' },
  { icon: Download, title: 'PDF & CSV export', text: 'Download a print-quality A4 PDF, or your data as a spreadsheet-friendly CSV.' },
  { icon: Lock, title: 'Private by design', text: 'No sign-up. Reports are saved only on your device and never uploaded.' },
  { icon: WifiOff, title: 'Works offline', text: 'Install it on your phone or computer and use it without internet.' },
];

const STEPS = [
  ['Enter your business details', 'Name, year and currency.'],
  ['Add your figures', "Last year's actuals and this year's projection."],
  ['Pick metrics & assumptions', 'Only the ones that matter to you.'],
  ['Preview & download', 'Get a polished PDF in one tap.'],
];

export default function Landing() {
  const sample = useMemo(() => sampleReport(), []);
  return (
    <div>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 sm:py-16 lg:grid-cols-[1fr_1.05fr]">
        <div>
          <div className="mb-5 flex items-center gap-3">
            <BizMark size={44} />
            <span className="text-3xl font-bold tracking-tight">BizForecast</span>
          </div>
          <h1 className="text-[34px] font-bold leading-[1.1] tracking-tight sm:text-5xl">Turn your business numbers into a professional projection report.</h1>
          <p className="mt-4 max-w-xl text-lg text-ink-soft">Enter last year's figures and your expectations for next year. BizForecast does the maths and designs a clear, print-ready financial projection report.</p>
          <div className="mt-7 flex flex-wrap gap-3">
            <Link to="/new" className="btn-primary btn !px-5 !py-3 text-base">
              Create new report <ArrowRight size={18} />
            </Link>
            <Link to="/report/sample" className="btn-secondary btn !px-5 !py-3 text-base">
              See a sample report
            </Link>
          </div>
          <p className="mt-4 text-xs text-muted">Free to use · No account needed · Your data stays on your device</p>
        </div>
        <div className="relative">
          <div className="relative h-[460px] overflow-hidden rounded-2xl border border-line bg-white shadow-xl shadow-black/5 sm:h-[520px]">
            <div className="pointer-events-none origin-top-left scale-[0.62] sm:scale-[0.72]" style={{ width: `${100 / 0.62}%` }} aria-hidden="true">
              <ReportView report={sample} />
            </div>
            <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-white to-transparent" />
          </div>
          <p className="mt-2 text-center text-xs text-muted">Sample report for a fictional business — demonstration data only.</p>
        </div>
      </section>

      <section className="border-y border-line bg-white">
        <div className="mx-auto max-w-6xl px-4 py-14">
          <h2 className="text-2xl font-bold tracking-tight">What you get</h2>
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="flex gap-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-ink text-white">
                  <f.icon size={18} />
                </span>
                <div>
                  <h3 className="font-semibold">{f.title}</h3>
                  <p className="mt-1 text-sm text-muted">{f.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-14">
        <h2 className="text-2xl font-bold tracking-tight">How it works</h2>
        <ol className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map(([t, s], i) => (
            <li key={t} className="card p-5">
              <span className="text-3xl font-bold text-brand-green">{i + 1}</span>
              <p className="mt-2 font-semibold">{t}</p>
              <p className="mt-1 text-sm text-muted">{s}</p>
            </li>
          ))}
        </ol>
        <div className="mt-10 text-center">
          <Link to="/new" className="btn-primary btn !px-6 !py-3 text-base">
            Create new report <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
}
