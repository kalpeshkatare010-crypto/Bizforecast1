import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Check, FileText, Save } from 'lucide-react';
import type { Assumptions, BusinessInfo, Customisation, Financials, Metric, Report } from '../types';
import { useErrors } from '../components/form';
import { draft, storage } from '../lib/storage';
import { newReport } from '../lib/defaults';
import { has } from '../lib/calc';
import StepBusiness from './wizard/StepBusiness';
import StepFinancials from './wizard/StepFinancials';
import StepMetrics from './wizard/StepMetrics';
import StepAssumptions from './wizard/StepAssumptions';
import StepCustomise from './wizard/StepCustomise';

const STEPS = [
  { title: 'Business', long: 'Business information', intro: 'Tell us about the business this report is for.' },
  { title: 'Financials', long: 'Financial figures', intro: "Enter last year's actual figures and what you expect for the projection year. Leave a box empty if you don't know it — it will not be shown as zero." },
  { title: 'Metrics', long: 'Performance metrics', intro: 'Add the numbers you track besides money. Everything here is optional.' },
  { title: 'Assumptions', long: 'Business assumptions', intro: 'What do you expect to happen, and why? Assumptions explain your projection to readers.' },
  { title: 'Customise', long: 'Customise the report', intro: 'Choose what appears on the report and how it looks.' },
];

export default function Wizard() {
  const { id } = useParams();
  const nav = useNavigate();
  const editing = Boolean(id);

  const initial = useMemo<Report | null>(() => {
    if (id) return storage.get(id) ?? null;
    return draft.get() ?? newReport();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [report, setReport] = useState<Report | null>(initial);
  const [step, setStep] = useState(0);
  const [restored] = useState(() => !id && draft.get() !== null);
  const [stepErrors, setStepErrors] = useState<Record<string, string>>({});
  const [saveError, setSaveError] = useState('');
  const num = useErrors();
  const topRef = useRef<HTMLDivElement>(null);

  // Autosave an unfinished new report as a draft
  useEffect(() => {
    if (report && !editing) draft.set(report);
  }, [report, editing]);

  if (!report) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <p className="text-lg font-semibold">Report not found</p>
        <p className="mt-1 text-sm text-muted">It may have been deleted from this device.</p>
        <button className="btn-primary btn mt-6" onClick={() => nav('/dashboard')}>
          Go to dashboard
        </button>
      </div>
    );
  }

  const up = (fn: (r: Report) => Report) => setReport((r) => (r ? fn(r) : r));
  const setBusiness = (p: Partial<BusinessInfo>) => up((r) => ({ ...r, business: { ...r.business, ...p } }));
  const setFin = (p: Partial<Financials>) => up((r) => ({ ...r, financials: { ...r.financials, ...p } }));
  const setMetrics = (m: Metric[]) => up((r) => ({ ...r, metrics: m }));
  const setAssume = (p: Partial<Assumptions>) => up((r) => ({ ...r, assumptions: { ...r.assumptions, ...p } }));
  const setCustom = (p: Partial<Customisation>) => up((r) => ({ ...r, custom: { ...r.custom, ...p } }));

  const validate = (s: number): Record<string, string> => {
    const e: Record<string, string> = {};
    const b = report.business;
    if (s === 0 || s === 4) {
      if (s === 0 && !b.name.trim()) e.name = 'Please enter the business name.';
      if (!Number.isInteger(b.reportingYear) || b.reportingYear < 1990 || b.reportingYear > 2100) e.reportingYear = 'Enter a year between 1990 and 2100, e.g. 2027.';
      if (s === 0 && b.preparedDate && Number.isNaN(new Date(b.preparedDate).getTime())) e.preparedDate = 'Please choose a valid date.';
    }
    if (s === 1) {
      const f = report.financials;
      if (!has(f.projRevenue)) e['fin.required'] = 'Please enter at least the projected revenue — it is the main figure of the report.';
      f.extra.forEach((x) => {
        if (!x.label.trim() && (has(x.prev) || has(x.proj))) e[`fin.extra.${x.id}.label`] = 'Give this figure a name, or remove it.';
      });
    }
    if (s === 2) {
      report.metrics.forEach((m) => {
        if (m.custom && !m.label.trim()) e[`met.${m.id}.label`] = 'Give your custom metric a name, or remove it.';
      });
    }
    if (s === 4) {
      (Object.keys(report.custom.headings) as (keyof typeof report.custom.headings)[]).forEach((k) => {
        if (!report.custom.headings[k].trim()) e[`h.${k}`] = 'Heading cannot be empty.';
      });
    }
    const prefix = ['', 'fin.', 'met.', 'as.', ''][s];
    if (prefix) for (const [k, v] of Object.entries(num.errors)) if (k.startsWith(prefix)) e[k] = v;
    return e;
  };

  const scrollTop = () => topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });

  const go = (to: number) => {
    if (to > step) {
      for (let s = step; s < to; s++) {
        const e = validate(s);
        if (Object.keys(e).length) {
          setStep(s);
          setStepErrors(e);
          scrollTop();
          return;
        }
      }
    }
    setStepErrors({});
    setStep(to);
    scrollTop();
  };

  const finish = (openPreview: boolean) => {
    for (let s = 0; s < STEPS.length; s++) {
      const e = validate(s);
      if (Object.keys(e).length) {
        setStep(s);
        setStepErrors(e);
        scrollTop();
        return;
      }
    }
    const ok = storage.save(report);
    if (!ok) {
      setSaveError('Could not save — this browser’s storage may be full or disabled (e.g. private browsing).');
      return;
    }
    if (!editing) draft.clear();
    nav(openPreview ? `/report/${report.id}` : '/dashboard');
  };

  const errors = { ...stepErrors };
  const s = STEPS[step];

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:py-10" ref={topRef}>
      <div className="mb-6 flex items-center justify-between gap-3">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-muted">{editing ? 'Edit report' : 'New report'}</p>
          <h1 className="text-2xl font-bold tracking-tight">{report.business.name || 'Untitled report'}</h1>
        </div>
        {step > 0 && (
          <button className="btn-secondary btn" onClick={() => finish(false)}>
            <Save size={16} /> <span className="hidden sm:inline">Save &amp; exit</span>
          </button>
        )}
      </div>

      {restored && !editing && step === 0 && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-line bg-white px-3 py-2 text-sm">
          <span>We restored your unfinished report.</span>
          <button
            className="font-semibold underline"
            onClick={() => {
              draft.clear();
              setReport(newReport());
              num.clear('');
            }}
          >
            Start fresh instead
          </button>
        </div>
      )}

      {report.isSample && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-sm text-amber-900">
          <span>This is a copy of the demonstration report, so it is labelled as sample data.</span>
          <button className="font-semibold underline" onClick={() => up((r) => ({ ...r, isSample: false }))}>
            I've replaced the figures with my own — remove the label
          </button>
        </div>
      )}

      {/* Stepper */}
      <ol className="mb-6 grid grid-cols-5 gap-1.5" aria-label="Progress">
        {STEPS.map((x, i) => (
          <li key={x.title}>
            <button type="button" onClick={() => go(i)} className="group w-full text-left" aria-current={i === step ? 'step' : undefined}>
              <span className={`block h-1.5 rounded-full ${i <= step ? 'bg-ink' : 'bg-line'}`} />
              <span className={`mt-1.5 hidden text-xs sm:block ${i === step ? 'font-semibold text-ink' : 'text-muted group-hover:text-ink'}`}>
                {i < step ? <Check size={12} className="mr-0.5 inline" /> : `${i + 1}. `}
                {x.title}
              </span>
            </button>
          </li>
        ))}
      </ol>

      <div className="mb-5">
        <p className="text-xs font-medium text-muted sm:hidden">
          Step {step + 1} of {STEPS.length}
        </p>
        <h2 className="text-xl font-bold">{s.long}</h2>
        <p className="mt-1 text-sm text-muted">{s.intro}</p>
      </div>

      {Object.keys(errors).length > 0 && (
        <div role="alert" className="mb-4 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
          Please fix the highlighted {Object.keys(errors).length === 1 ? 'field' : 'fields'} before continuing.
        </div>
      )}

      {step === 0 && <StepBusiness b={report.business} set={setBusiness} errors={errors} />}
      {step === 1 && <StepFinancials report={report} set={setFin} reporter={num.reporter} errors={errors} />}
      {step === 2 && <StepMetrics report={report} setMetrics={setMetrics} reporter={num.reporter} clear={num.clear} errors={errors} />}
      {step === 3 && <StepAssumptions report={report} set={setAssume} setFin={setFin} reporter={num.reporter} />}
      {step === 4 && <StepCustomise report={report} set={setCustom} setYear={(y) => setBusiness({ reportingYear: y })} errors={errors} />}

      {saveError && <p className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{saveError}</p>}

      <div className="sticky bottom-0 -mx-4 mt-8 flex items-center justify-between gap-3 border-t border-line bg-canvas/95 px-4 py-3 backdrop-blur sm:static sm:mx-0 sm:border-0 sm:bg-transparent sm:px-0">
        <button className="btn-secondary btn" onClick={() => (step === 0 ? nav(-1) : go(step - 1))}>
          <ArrowLeft size={16} /> {step === 0 ? 'Cancel' : 'Back'}
        </button>
        {step < STEPS.length - 1 ? (
          <div className="flex gap-2">
            {(step === 2 || step === 3) && (
              <button className="btn-ghost btn hidden sm:inline-flex" onClick={() => go(step + 1)}>
                Skip
              </button>
            )}
            <button className="btn-primary btn" onClick={() => go(step + 1)}>
              Next <ArrowRight size={16} />
            </button>
          </div>
        ) : (
          <button className="btn-primary btn" onClick={() => finish(true)}>
            <FileText size={16} /> Generate report
          </button>
        )}
      </div>
    </div>
  );
}
