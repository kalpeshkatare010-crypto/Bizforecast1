/** A numeric input that may be left empty. `null` means "not entered" — never treated as zero. */
export type Num = number | null;

export type MetricUnit = 'number' | 'percent' | 'currency';
export type MetricGroup = 'customers' | 'traffic' | 'sales' | 'rates' | 'other';

export interface BusinessInfo {
  name: string;
  category: string;
  description: string;
  /** The projected year the report is about, e.g. 2027 */
  reportingYear: number;
  /** Free text such as "FY 2026–27" or "Jan–Dec 2027" */
  financialYear: string;
  currency: string;
  /** ISO date (yyyy-mm-dd) */
  preparedDate: string;
}

export interface ExtraFigure {
  id: string;
  label: string;
  prev: Num;
  proj: Num;
}

export interface Financials {
  prevRevenue: Num;
  projRevenue: Num;
  prevExpenses: Num;
  projExpenses: Num;
  /** Leave null to calculate as revenue − expenses */
  prevProfit: Num;
  projProfit: Num;
  extra: ExtraFigure[];
}

export interface Metric {
  id: string;
  /** Preset key from the catalogue, or 'custom' */
  key: string;
  label: string;
  unit: MetricUnit;
  group: MetricGroup;
  prev: Num;
  proj: Num;
  custom: boolean;
  note?: string;
}

export interface AssumptionNote {
  id: string;
  label: string;
  value: string;
}

export interface Assumptions {
  revenueGrowth: Num; // %
  expenseGrowth: Num; // %
  customerGrowth: Num; // %
  retention: Num; // %
  notes: AssumptionNote[];
}

export type ThemeId = 'classic' | 'ocean' | 'graphite';
export type Orientation = 'portrait' | 'landscape';

export interface KpiToggles {
  projectedRevenue: boolean;
  projectedProfit: boolean;
  revenueGrowth: boolean;
  profitMargin: boolean;
  projectedExpenses: boolean;
  profitGrowth: boolean;
}

export interface ChartToggles {
  financialComparison: boolean;
  customerComparison: boolean;
  metricsTable: boolean;
  rateDonuts: boolean;
}

export interface Headings {
  title: string;
  summary: string;
  highlights: string;
  comparison: string;
  customers: string;
  performance: string;
  growth: string;
  custom: string;
  assumptions: string;
}

export interface Customisation {
  kpis: KpiToggles;
  charts: ChartToggles;
  headings: Headings;
  /** User-written summary. If empty, an automatic summary is generated from the figures. */
  executiveSummary: string;
  theme: ThemeId;
  orientation: Orientation;
}

export interface Report {
  id: string;
  createdAt: string;
  updatedAt: string;
  isSample: boolean;
  business: BusinessInfo;
  financials: Financials;
  metrics: Metric[];
  assumptions: Assumptions;
  custom: Customisation;
}
