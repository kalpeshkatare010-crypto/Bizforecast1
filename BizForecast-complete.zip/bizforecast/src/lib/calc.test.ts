import { describe, expect, it } from 'vitest';
import { applyGrowth, derive, effectiveProfit, fmtChange, fmtMoney, growth, margin, metricChange, parseNum, profitMismatch } from './calc';
import { sampleReport } from './sample';
import { newReport } from './defaults';
import { autoSummary } from './summary';
import { toCsv } from './csv';

describe('parseNum', () => {
  it('parses grouped and decimal numbers', () => {
    expect(parseNum('1,25,000')).toBe(125000);
    expect(parseNum(' 12.5 ')).toBe(12.5);
    expect(parseNum('-300')).toBe(-300);
    expect(parseNum('8%')).toBe(8);
  });
  it('treats empty as null and junk as NaN', () => {
    expect(parseNum('')).toBeNull();
    expect(Number.isNaN(parseNum('12abc'))).toBe(true);
  });
});

describe('growth', () => {
  it('computes percentage change', () => {
    const g = growth(4860000, 5640000);
    expect(g.kind).toBe('pct');
    if (g.kind === 'pct') expect(g.value).toBeCloseTo(16.0494, 3);
  });
  it('does not divide by zero', () => {
    expect(growth(0, 100)).toEqual({ kind: 'na', reason: 'zero-base' });
  });
  it('refuses misleading % from a negative base', () => {
    expect(growth(-50000, 20000)).toEqual({ kind: 'na', reason: 'negative-base' });
  });
  it('handles missing values', () => {
    expect(growth(null, 10)).toEqual({ kind: 'na', reason: 'missing' });
  });
  it('rates change in percentage points', () => {
    expect(metricChange({ unit: 'percent', prev: 11, proj: 8 })).toEqual({ kind: 'pp', value: -3 });
    expect(fmtChange({ kind: 'pp', value: -3 })).toBe('−3 pts');
  });
});

describe('profit and margin', () => {
  it('calculates profit when left blank', () => {
    expect(effectiveProfit(null, 1000, 700)).toEqual({ value: 300, source: 'calculated' });
    expect(effectiveProfit(250, 1000, 700)).toEqual({ value: 250, source: 'entered' });
    expect(effectiveProfit(null, 1000, null).source).toBe('missing');
  });
  it('flags a profit that does not match revenue − expenses', () => {
    expect(profitMismatch(250, 1000, 700)).toBe(300);
    expect(profitMismatch(300, 1000, 700)).toBeNull();
  });
  it('margin requires positive revenue', () => {
    expect(margin(300, 1000)).toBe(30);
    expect(margin(300, 0)).toBeNull();
    expect(margin(-100, 1000)).toBe(-10);
  });
  it('applies growth assumptions', () => {
    expect(applyGrowth(4860000, 16)).toBe(5637600);
  });
});

describe('sample report', () => {
  const d = derive(sampleReport());
  it('derives correct headline figures', () => {
    expect(d.profit.prev.value).toBe(940000);
    expect(d.profit.proj.value).toBe(1230000);
    expect(d.marginProj).toBeCloseTo(21.8085, 3);
    if (d.profit.change.kind === 'pct') expect(d.profit.change.value).toBeCloseTo(30.851, 2);
    if (d.expenses.change.kind === 'pct') expect(d.expenses.change.value).toBeCloseTo(12.5, 6);
  });
  it('builds a summary that only uses entered figures', () => {
    const s = autoSummary(sampleReport());
    expect(s).toContain('16%');
    expect(s).toContain('21.8%');
  });
  it('empty report summary contains no figures', () => {
    const s = autoSummary(newReport());
    expect(s).not.toMatch(/\d+%/);
  });
});

describe('formatting & csv', () => {
  it('formats INR with Indian grouping', () => {
    expect(fmtMoney(5640000, 'INR')).toBe('₹56,40,000');
    expect(fmtMoney(null, 'INR')).toBe('—');
  });
  it('csv leaves empty values blank, not zero, and escapes quotes', () => {
    const r = newReport();
    r.business.name = 'Acme "Best" Co';
    r.financials.projRevenue = 1000;
    const csv = toCsv(r);
    expect(csv).toContain('"Acme ""Best"" Co"');
    expect(csv).toMatch(/Revenue,,1000/);
  });
});
