import { jsPDF } from 'jspdf';
import type { Metric, Report } from '../types';
import { derive, fmtChange, fmtDate, fmtMetric, fmtMoney, fmtMoneyCompact, fmtCompact, fmtPct, fmtSigned, has, metricChange, type Change } from './calc';
import { GROUP_LABEL, THEMES } from './defaults';
import { summaryText } from './summary';
import { fileSafe, downloadBlob } from './csv';
import interRegular from '../assets/fonts/interRegular';
import interBold from '../assets/fonts/interBold';
import interItalic from '../assets/fonts/interItalic';
import interSemiBold from '../assets/fonts/interSemiBold';
import rkLogo from '../assets/rkLogo';

/*
 * Vector PDF generator. Every element (text, tables, bar charts, donuts) is drawn natively,
 * so the PDF is sharp at any zoom, text is selectable and nothing is a screenshot.
 */

const DISCLAIMER =
  'Financial projections are estimates based on user-provided information and assumptions. They do not guarantee future business performance and should not be treated as professional accounting, investment or tax advice.';

type RGB = [number, number, number];
const hex = (h: string): RGB => {
  const s = h.replace('#', '');
  return [parseInt(s.slice(0, 2), 16), parseInt(s.slice(2, 4), 16), parseInt(s.slice(4, 6), 16)];
};
const tint = (h: string, a: number): RGB => hex(h).map((c) => Math.round(c * a + 255 * (1 - a))) as RGB;
const INK: RGB = [23, 26, 31];
const SOFT: RGB = [58, 63, 71];
const MUTED: RGB = [107, 113, 123];
const LINE: RGB = [222, 224, 228];
const HEAD: RGB = [222, 222, 222];
const ROWBG: RGB = [243, 243, 243];

type Weight = 'normal' | 'bold' | 'italic' | 'semibold';

class Pdf {
  doc: jsPDF;
  W: number;
  H: number;
  m = 16;
  y = 16;
  cw: number;

  constructor(orientation: 'portrait' | 'landscape') {
    this.doc = new jsPDF({ orientation, unit: 'mm', format: 'a4', compress: true });
    const d = this.doc;
    d.addFileToVFS('Inter-Regular.ttf', interRegular);
    d.addFont('Inter-Regular.ttf', 'Inter', 'normal');
    d.addFileToVFS('Inter-Bold.ttf', interBold);
    d.addFont('Inter-Bold.ttf', 'Inter', 'bold');
    d.addFileToVFS('Inter-Italic.ttf', interItalic);
    d.addFont('Inter-Italic.ttf', 'Inter', 'italic');
    d.addFileToVFS('Inter-SemiBold.ttf', interSemiBold);
    d.addFont('Inter-SemiBold.ttf', 'Inter', 'semibold');
    this.W = d.internal.pageSize.getWidth();
    this.H = d.internal.pageSize.getHeight();
    this.cw = this.W - this.m * 2;
  }

  font(w: Weight, size: number, color: RGB = INK) {
    this.doc.setFont('Inter', w);
    this.doc.setFontSize(size);
    this.doc.setTextColor(...color);
  }
  fill(c: RGB) {
    this.doc.setFillColor(...c);
  }
  stroke(c: RGB, w = 0.2) {
    this.doc.setDrawColor(...c);
    this.doc.setLineWidth(w);
  }
  get bottom() {
    return this.H - 18;
  }
  ensure(h: number) {
    if (this.y + h > this.bottom) this.newPage();
  }
  newPage() {
    this.doc.addPage();
    this.y = this.m;
  }
  tw(s: string) {
    return this.doc.getTextWidth(s);
  }
  /** Fit text into width by reducing the font size. */
  fitSize(s: string, w: Weight, size: number, maxW: number, min = 7) {
    let sz = size;
    this.font(w, sz);
    while (sz > min && this.tw(s) > maxW) {
      sz -= 0.5;
      this.font(w, sz);
    }
    return sz;
  }
  wrap(s: string, maxW: number) {
    return this.doc.splitTextToSize(s, maxW) as string[];
  }
  lineH(size: number, k = 1.35) {
    return (size * 0.3528) * k;
  }
  rule(y: number, w = 0.3, c: RGB = INK) {
    this.stroke(c, w);
    this.doc.line(this.m, y, this.W - this.m, y);
  }

  iconBadge(x: number, y: number, kind: 'chart' | 'users' | 'target' | 'cycle' | 'star' | 'list') {
    const r = 4.2;
    const cx = x + r;
    const cy = y + r;
    this.fill(INK);
    this.doc.circle(cx, cy, r, 'F');
    const d = this.doc;
    d.setFillColor(255, 255, 255);
    d.setDrawColor(255, 255, 255);
    d.setLineWidth(0.45);
    switch (kind) {
      case 'chart':
        d.rect(cx - 2.2, cy, 1, 1.8, 'F');
        d.rect(cx - 0.5, cy - 1.4, 1, 3.2, 'F');
        d.rect(cx + 1.2, cy - 0.6, 1, 2.4, 'F');
        break;
      case 'users':
        d.circle(cx, cy - 0.9, 1.1, 'F');
        d.ellipse(cx, cy + 1.7, 2.1, 1.1, 'F');
        break;
      case 'target':
        d.circle(cx, cy, 2.2, 'S');
        d.circle(cx, cy, 0.8, 'F');
        break;
      case 'cycle':
        d.circle(cx, cy, 2, 'S');
        d.setFillColor(...INK);
        d.rect(cx + 0.3, cy - 2.6, 2.5, 2.3, 'F');
        d.setFillColor(255, 255, 255);
        d.triangle(cx + 0.2, cy - 2.9, cx + 0.2, cy - 1.1, cx + 1.6, cy - 2, 'F');
        break;
      case 'star':
        d.triangle(cx, cy - 2.3, cx - 2, cy + 1.6, cx + 2, cy + 1.6, 'F');
        d.triangle(cx, cy + 2.3, cx - 2, cy - 1, cx + 2, cy - 1, 'F');
        break;
      case 'list':
        for (let i = -1; i <= 1; i++) {
          d.circle(cx - 1.6, cy + i * 1.3, 0.3, 'F');
          d.line(cx - 0.8, cy + i * 1.3, cx + 2, cy + i * 1.3);
        }
        break;
    }
  }

  sectionTitle(title: string, icon: Parameters<Pdf['iconBadge']>[2], x = this.m, w = this.cw) {
    this.iconBadge(x, this.y, icon);
    const sz = this.fitSize(title, 'bold', 14, w - 12);
    this.font('bold', sz);
    this.doc.text(title, x + 11.5, this.y + 5.6);
    this.y += 12.5;
  }

  /** Grouped bar chart: previous vs projected. */
  bars(
    x: number,
    y: number,
    w: number,
    h: number,
    data: { name: string; prev: number | null; proj: number | null }[],
    colors: { prev: string; proj: string },
    labels: [string, string],
    fmt: (v: number) => string,
  ) {
    const d = this.doc;
    // legend
    this.font('normal', 7, SOFT);
    let lx = x;
    for (const [i, lab] of labels.entries()) {
      const lw = this.tw(lab) + 9;
      d.setFillColor(236, 236, 236);
      d.rect(lx, y, lw, 5, 'F');
      this.fill(hex(i === 0 ? colors.prev : colors.proj));
      d.rect(lx + 1.5, y + 1.4, 4, 2.2, 'F');
      d.text(lab, lx + 7, y + 3.5);
      lx += lw + 3;
    }
    const top = y + 11;
    const labelBand = 6;
    const plotH = h - (top - y) - labelBand;
    const vals = data.flatMap((v) => [v.prev, v.proj]).filter(has);
    const max = Math.max(0, ...vals);
    const min = Math.min(0, ...vals);
    const span = max - min || 1;
    const scale = (plotH - 5) / span;
    const zeroY = top + 5 + max * scale;
    // grid
    this.stroke([230, 230, 230], 0.15);
    for (let i = 0; i <= 4; i++) {
      const gy = top + 5 + ((plotH - 5) * i) / 4;
      d.line(x, gy, x + w, gy);
    }
    const groupW = w / data.length;
    const barW = Math.min(groupW * 0.32, 22);
    const gap = Math.min(groupW * 0.05, 2.5);
    data.forEach((g, i) => {
      const cx = x + groupW * i + groupW / 2;
      ([
        [g.prev, cx - gap / 2 - barW, colors.prev],
        [g.proj, cx + gap / 2, colors.proj],
      ] as const).forEach(([v, bx, col]) => {
        if (!has(v)) return;
        const bh = Math.abs(v) * scale;
        const by = v >= 0 ? zeroY - bh : zeroY;
        this.fill(hex(col));
        d.rect(bx, by, barW, Math.max(bh, 0.3), 'F');
        const label = fmt(v);
        const sz = this.fitSize(label, 'normal', 7.5, barW + gap + 4, 5.5);
        this.font('normal', sz, INK);
        const ly = v >= 0 ? by - 1.3 : by + bh + 3;
        d.text(label, bx + barW / 2, ly, { align: 'center' });
      });
      this.font('normal', 8.5, INK);
      const nm = this.wrap(g.name, groupW - 2)[0];
      d.text(nm, cx, top + plotH + 4.5, { align: 'center' });
    });
    this.stroke(INK, 0.35);
    d.line(x, zeroY, x + w, zeroY);
  }

  donut(cx: number, cy: number, r: number, value: number, color: string, track: string, label: string, labelColor: RGB, labelSize: number) {
    const d = this.doc;
    const v = Math.max(0, Math.min(100, value));
    this.fill(hex(track));
    d.circle(cx, cy, r, 'F');
    if (v > 0) {
      this.fill(hex(color));
      if (v >= 99.95) d.circle(cx, cy, r, 'F');
      else {
        const steps = Math.max(8, Math.ceil(v * 1.2));
        const pts: [number, number][] = [[cx, cy]];
        for (let i = 0; i <= steps; i++) {
          const a = -Math.PI / 2 + (2 * Math.PI * (v / 100) * i) / steps;
          pts.push([cx + r * Math.cos(a), cy + r * Math.sin(a)]);
        }
        const rel = pts.slice(1).map((p, i) => [p[0] - pts[i][0], p[1] - pts[i][1]]);
        d.lines(rel, cx, cy, [1, 1], 'F', true);
      }
    }
    d.setFillColor(255, 255, 255);
    d.circle(cx, cy, r * 0.68, 'F');
    this.font('bold', labelSize, labelColor);
    d.text(label, cx, cy + labelSize * 0.3528 * 0.36, { align: 'center' });
  }

  /** Table with wrapping cells and repeated header across pages. */
  table(
    cols: { title: string; w: number; align?: 'left' | 'right'; bg?: RGB }[],
    rows: string[][],
    opts: { headBg?: RGB; size?: number; firstColBg?: RGB } = {},
  ) {
    const d = this.doc;
    const size = opts.size ?? 8.5;
    const pad = 2;
    const gap = 0.5;
    const drawHead = () => {
      const hh = 7.5;
      let x = this.m;
      for (const c of cols) {
        this.fill(opts.headBg ?? HEAD);
        d.rect(x, this.y, c.w - gap, hh, 'F');
        this.font('semibold', size, INK);
        const tx = c.align === 'right' ? x + c.w - gap - pad : x + pad;
        d.text(this.wrap(c.title, c.w - pad * 2)[0], tx, this.y + 4.9, { align: c.align === 'right' ? 'right' : 'left' });
        x += c.w;
      }
      this.y += hh + gap;
    };
    this.ensure(7.5 + 8);
    drawHead();
    for (const row of rows) {
      this.font('normal', size);
      const lines = row.map((cell, i) => this.wrap(cell, cols[i].w - pad * 2 - gap));
      const n = Math.max(...lines.map((l) => l.length));
      const rh = Math.max(7, n * this.lineH(size, 1.25) + 3.2);
      if (this.y + rh > this.bottom) {
        this.newPage();
        drawHead();
      }
      let x = this.m;
      cols.forEach((c, i) => {
        const bg = c.bg ?? (i === 0 ? (opts.firstColBg ?? ROWBG) : ROWBG);
        this.fill(bg);
        d.rect(x, this.y, c.w - gap, rh, 'F');
        this.font('normal', size, INK);
        const tx = c.align === 'right' ? x + c.w - gap - pad : x + pad;
        lines[i].forEach((ln, j) => d.text(ln, tx, this.y + 4.6 + j * this.lineH(size, 1.25), { align: c.align === 'right' ? 'right' : 'left' }));
        x += c.w;
      });
      this.y += rh + gap;
    }
  }

  footer(isSample: boolean) {
    const d = this.doc;
    const n = d.getNumberOfPages();
    for (let i = 1; i <= n; i++) {
      d.setPage(i);
      const fy = this.H - 9;
      this.stroke(LINE, 0.2);
      d.line(this.m, fy - 4, this.W - this.m, fy - 4);
      d.addImage(rkLogo, 'PNG', this.m, fy - 2.6, 3.4, 3.4);
      this.font('normal', 7, MUTED);
      d.text('BizForecast | Generated using RK Digitals', this.m + 4.6, fy);
      if (isSample) {
        this.font('semibold', 7, [161, 98, 7]);
        d.text('DEMONSTRATION — sample data', this.W / 2, fy, { align: 'center' });
      }
      this.font('normal', 7, MUTED);
      d.text(`Page ${i} of ${n}`, this.W - this.m, fy, { align: 'right' });
    }
  }
}

const LOWER_IS_BETTER = new Set(['churn']);

export function buildPdf(r: Report): jsPDF {
  const p = new Pdf(r.custom.orientation);
  const doc = p.doc;
  const d = derive(r);
  const t = THEMES[r.custom.theme] ?? THEMES.classic;
  const cur = r.business.currency;
  const H = r.custom.headings;
  const ch = r.custom.charts;
  const k = r.custom.kpis;
  const projYear = r.business.reportingYear;
  const prevYear = projYear - 1;
  const legend: [string, string] = [`${prevYear} Actual`, `${projYear} Projection`];
  const landscape = r.custom.orientation === 'landscape';

  doc.setProperties({ title: `${r.business.name} — ${H.title} ${projYear}`, creator: 'BizForecast by RK Digitals', subject: 'Financial projection report' });

  /* ---------- Header ---------- */
  if (r.isSample) {
    p.fill([255, 247, 230]);
    doc.rect(p.m, p.y, p.cw, 7, 'F');
    p.font('semibold', 8, [146, 64, 14]);
    doc.text('DEMONSTRATION REPORT — fictional business with sample figures only', p.W / 2, p.y + 4.6, { align: 'center' });
    p.y += 11;
  }
  const name = r.business.name || 'Untitled business';
  const cat = r.business.category;
  p.font('bold', 13);
  const nameW = p.tw(name);
  p.font('italic', 13, SOFT);
  const catW = cat ? p.tw('  ' + cat) : 0;
  let hx = p.W / 2 - (nameW + catW) / 2;
  if (nameW + catW > p.cw) hx = p.m;
  p.font('bold', 13);
  doc.text(name, hx, p.y + 5);
  if (cat) {
    p.font('italic', 13, SOFT);
    doc.text('  ' + cat, hx + nameW, p.y + 5);
  }
  p.y += 8;
  const title = `${H.title} for ${projYear}`;
  const tsz = p.fitSize(title, 'bold', landscape ? 28 : 25, p.cw, 14);
  p.font('bold', tsz);
  doc.text(title, p.W / 2, p.y + p.lineH(tsz, 0.85), { align: 'center' });
  p.y += p.lineH(tsz, 1.05) + 2;
  p.fill(INK);
  doc.rect(p.m, p.y, p.cw, 1.5, 'F');
  p.y += 5;
  const meta = [r.business.financialYear, r.business.preparedDate && `Prepared ${fmtDate(r.business.preparedDate)}`, `Currency: ${cur}`].filter(Boolean).join('     ');
  p.font('normal', 8, MUTED);
  doc.text(meta, p.W / 2, p.y, { align: 'center' });
  p.y += 8;

  /* ---------- Summary + financial chart ---------- */
  const finBars = [
    { name: 'Revenue', prev: d.revenue.prev, proj: d.revenue.proj },
    { name: 'Expenses', prev: d.expenses.prev, proj: d.expenses.proj },
    { name: 'Profit', prev: d.profit.prev.value, proj: d.profit.proj.value },
  ].filter((x) => has(x.prev) || has(x.proj));
  const showFin = ch.financialComparison && finBars.length > 0;
  const leftW = showFin ? p.cw * (landscape ? 0.38 : 0.4) : p.cw;
  const rightX = p.m + leftW + 8;
  const rightW = p.cw - leftW - 8;

  const summary = summaryText(r);
  p.font('normal', 9.5, SOFT);
  const sLines = p.wrap(summary, leftW);
  const sLH = p.lineH(9.5, 1.45);
  const bigH = has(d.revenue.proj) ? 18 : 0;
  const leftH = 5 + sLines.length * sLH + bigH;
  const chartH = landscape ? 78 : 72;
  const blockH = Math.max(leftH, showFin ? chartH + 10 : 0);
  if (blockH < p.bottom - p.m) p.ensure(blockH);
  const top = p.y;
  const startPage = doc.getNumberOfPages();
  p.font('semibold', 7.5, MUTED);
  doc.text(H.summary.toUpperCase(), p.m, top + 2);
  let ly = top + 7;
  p.font('normal', 9.5, SOFT);
  for (const ln of sLines) {
    if (ly > p.bottom) {
      p.newPage();
      ly = p.y + 4;
      p.font('normal', 9.5, SOFT);
    }
    doc.text(ln, p.m, ly);
    ly += sLH;
  }
  if (has(d.revenue.proj)) {
    p.font('normal', 7.5, MUTED);
    doc.text(`Projected revenue for ${projYear}`, p.m, ly + 2);
    const val = fmtMoney(d.revenue.proj, cur);
    const sz = p.fitSize(val, 'bold', 24, leftW, 12);
    p.font('bold', sz, hex(t.accent));
    doc.text(val, p.m, ly + 2 + p.lineH(sz, 1.05));
    ly += 4 + p.lineH(sz, 1.1);
  }
  const endPage = doc.getNumberOfPages();
  if (showFin) {
    doc.setPage(startPage);
    p.y = top;
    p.iconBadge(rightX, top, 'chart');
    const hs = p.fitSize(H.comparison, 'bold', 11, rightW - 12);
    p.font('bold', hs);
    doc.text(H.comparison, rightX + 11.5, top + 5.4);
    p.bars(rightX, top + 11, rightW, chartH, finBars, t, legend, (v) => fmtMoneyCompact(v, cur));
    if (d.profit.prev.source === 'calculated' || d.profit.proj.source === 'calculated') {
      p.font('normal', 6.5, MUTED);
      doc.text('Profit calculated as revenue minus expenses.', rightX, top + 11 + chartH + 3.5);
    }
  }
  doc.setPage(endPage);
  p.y = (endPage === startPage ? Math.max(ly, showFin ? top + 11 + chartH + 6 : 0) : ly) + 4;

  /* ---------- Highlights ---------- */
  const tiles: { label: string; value: string; sub: string; subColor?: RGB }[] = [];
  const chText = (c: Change, invert = false): [string, RGB] => {
    if (c.kind === 'na') return [c.reason === 'missing' ? '' : '% change n/a', MUTED];
    const good = invert ? c.value < 0 : c.value > 0;
    return [`${fmtChange(c)} vs ${prevYear}`, Math.abs(c.value) < 0.05 ? MUTED : good ? [21, 128, 61] : [220, 38, 38]];
  };
  if (k.projectedRevenue && has(d.revenue.proj)) {
    const [s, c] = chText(d.revenue.change);
    tiles.push({ label: `Projected revenue ${projYear}`, value: fmtMoney(d.revenue.proj, cur), sub: s, subColor: c });
  }
  if (k.projectedProfit && has(d.profit.proj.value)) {
    const [s, c] = d.profit.proj.source === 'calculated' ? ['Revenue − expenses', MUTED] : chText(d.profit.change);
    tiles.push({ label: d.profit.proj.value >= 0 ? `Projected profit ${projYear}` : `Projected loss ${projYear}`, value: fmtMoney(d.profit.proj.value, cur), sub: s as string, subColor: c as RGB });
  }
  if (k.revenueGrowth && d.revenue.change.kind === 'pct') tiles.push({ label: 'Revenue growth', value: fmtChange(d.revenue.change), sub: `vs ${prevYear}` });
  if (k.profitMargin && d.marginProj !== null) tiles.push({ label: 'Profit margin', value: fmtPct(d.marginProj), sub: d.marginChangePp !== null ? `${fmtSigned(d.marginChangePp)} pts vs ${prevYear}` : '' });
  if (k.projectedExpenses && has(d.expenses.proj)) {
    const [s, c] = chText(d.expenses.change, true);
    tiles.push({ label: `Projected expenses ${projYear}`, value: fmtMoney(d.expenses.proj, cur), sub: s, subColor: c });
  }
  if (k.profitGrowth && d.profit.change.kind === 'pct') tiles.push({ label: 'Profit growth', value: fmtChange(d.profit.change), sub: `vs ${prevYear}` });

  if (tiles.length) {
    p.ensure(12 + 24);
    p.rule(p.y, 0.3);
    p.y += 7;
    p.font('bold', 14);
    doc.text(H.highlights, p.m, p.y + 1);
    p.y += 6;
    const perRow = tiles.length <= 4 ? tiles.length : 3;
    const gap = 4;
    const tw = (p.cw - gap * (perRow - 1)) / perRow;
    tiles.forEach((tile, i) => {
      const col = i % perRow;
      if (col === 0 && i > 0) p.y += 26;
      if (col === 0) p.ensure(24);
      const x = p.m + col * (tw + gap);
      p.stroke(LINE, 0.3);
      doc.roundedRect(x, p.y, tw, 23, 1.5, 1.5, 'S');
      p.font('normal', 7.5, MUTED);
      doc.text(p.wrap(tile.label, tw - 6)[0], x + 3, p.y + 5.5);
      const sz = p.fitSize(tile.value, 'bold', 15, tw - 6, 8);
      p.font('bold', sz, INK);
      doc.text(tile.value, x + 3, p.y + 13.5);
      if (tile.sub) {
        p.font('semibold', 7, tile.subColor ?? MUTED);
        doc.text(p.wrap(tile.sub, tw - 6)[0], x + 3, p.y + 19.2);
      }
    });
    p.y += 31;
  }

  /* ---------- Customers + retention ---------- */
  const custBars = d.customerMetrics.map((m) => ({ name: m.label.replace(/ customers$/i, ''), prev: m.prev, proj: m.proj }));
  const showCust = ch.customerComparison && custBars.length > 0;
  const showDonuts = ch.rateDonuts;
  const ret = showDonuts ? d.retention : null;
  if (showCust || ret) {
    const blockH = 84;
    p.ensure(blockH + 8);
    p.rule(p.y, 0.3);
    p.y += 7;
    const top2 = p.y;
    const both = showCust && ret;
    const cw1 = both ? p.cw * 0.56 : p.cw;
    if (showCust) {
      p.y = top2;
      p.sectionTitle(H.customers, 'users', p.m, cw1);
      p.bars(p.m, p.y, cw1, blockH - 14, custBars, t, legend, (v) => fmtCompact(v));
    }
    if (ret) {
      const x0 = both ? p.m + cw1 + 8 : p.m;
      const w0 = both ? p.cw - cw1 - 8 : p.cw;
      if (both) {
        p.stroke(INK, 0.3);
        doc.line(x0 - 4, top2, x0 - 4, top2 + blockH);
      }
      p.y = top2;
      p.sectionTitle(H.growth, 'cycle', x0, w0);
      p.font('semibold', 8.5, SOFT);
      doc.text('Projected Customer Retention Rate', x0 + w0 / 2, p.y + 1, { align: 'center' });
      const r0 = Math.min(w0 / 2 - 4, 30);
      p.donut(x0 + w0 / 2, p.y + 6 + r0, r0, ret.value, t.proj, t.track, fmtPct(ret.value), hex(t.accent), r0 * 0.95);
      const cap = ret.source === 'assumption' ? '(Your assumption)' : has(ret.prev) ? `(${fmtSigned(ret.value - ret.prev)} percentage points from ${prevYear})` : `(Projected for ${projYear})`;
      p.font('italic', 7.5, SOFT);
      doc.text(cap, x0 + w0 / 2, p.y + 12 + r0 * 2, { align: 'center' });
    }
    p.y = top2 + blockH + 6;
  }

  /* ---------- Performance tables ---------- */
  const tableMetrics = d.presetMetrics.filter((m) => !(m.group === 'customers' && showCust && m.unit === 'number'));
  const groups = (['customers', 'traffic', 'sales', 'rates', 'other'] as const)
    .map((g) => ({ g, items: tableMetrics.filter((m) => m.group === g) }))
    .filter((x) => x.items.length);
  const metricRows = (items: Metric[]) =>
    items.map((m) => [m.label, fmtMetric(m.prev, m.unit, cur), fmtMetric(m.proj, m.unit, cur), fmtChange(metricChange(m))]);
  const metricCols = () => {
    const w = p.cw;
    return [
      { title: 'Metric', w: w * 0.4 },
      { title: String(prevYear), w: w * 0.2, align: 'right' as const, bg: tint(t.prev, 0.4) },
      { title: String(projYear), w: w * 0.2, align: 'right' as const, bg: tint(t.proj, 0.4) },
      { title: 'Change', w: w * 0.2, align: 'right' as const },
    ];
  };
  if (ch.metricsTable && groups.length) {
    p.ensure(14 + 30);
    p.rule(p.y, 0.3);
    p.y += 7;
    p.sectionTitle(H.performance, 'target');
    for (const { g, items } of groups) {
      if (groups.length > 1) {
        p.ensure(6 + 16);
        p.font('semibold', 7.5, MUTED);
        doc.text(GROUP_LABEL[g].toUpperCase(), p.m, p.y + 2);
        p.y += 4;
      }
      p.table(metricCols(), metricRows(items));
      p.y += 4;
    }
    if (groups.some((x) => x.items.some((m) => m.unit === 'percent'))) {
      p.font('normal', 6.5, MUTED);
      doc.text('For rates, change is shown in percentage points (pts).', p.m, p.y);
      p.y += 5;
    }
  }

  /* ---------- Small rate donuts ---------- */
  if (showDonuts) {
    const small = d.rateMetrics
      .filter((m) => m.key !== 'retention')
      .map((m) => ({ label: m.label, v: m.proj as number, cap: has(m.prev) ? `${fmtPct(m.prev, 2)} in ${prevYear}` : `Projected ${projYear}`, inv: LOWER_IS_BETTER.has(m.key) }));
    if (d.marginProj !== null && d.marginProj >= 0 && d.marginProj <= 100)
      small.push({ label: 'Profit margin', v: d.marginProj, cap: d.marginPrev !== null ? `${fmtPct(d.marginPrev)} in ${prevYear}` : `Projected ${projYear}`, inv: false });
    if (small.length) {
      const per = landscape ? 5 : 4;
      const cellW = p.cw / per;
      const rad = Math.min(cellW / 2 - 6, 13);
      const rowH = rad * 2 + 16;
      p.ensure(14 + rowH);
      p.rule(p.y, 0.3);
      p.y += 7;
      if (!ret) p.sectionTitle(H.growth, 'cycle');
      else {
        p.font('bold', 11);
        doc.text('Key rates', p.m, p.y + 2);
        p.y += 7;
      }
      small.forEach((s, i) => {
        const col = i % per;
        if (col === 0 && i > 0) p.y += rowH;
        if (col === 0) p.ensure(rowH);
        const cx = p.m + cellW * col + cellW / 2;
        p.donut(cx, p.y + rad, rad, s.v, s.inv ? t.prev : t.proj, t.track, fmtPct(s.v), INK, rad * 0.75);
        p.font('semibold', 7.5, INK);
        p.wrap(s.label, cellW - 4).slice(0, 2).forEach((ln, j) => doc.text(ln, cx, p.y + rad * 2 + 5 + j * 3.2, { align: 'center' }));
        p.font('normal', 6.5, MUTED);
        doc.text(s.cap, cx, p.y + rad * 2 + 5 + Math.min(2, p.wrap(s.label, cellW - 4).length) * 3.2 + 0.5, { align: 'center' });
      });
      p.y += rowH + 2;
    }
  }

  /* ---------- Custom KPIs ---------- */
  if (d.customMetrics.length) {
    const per = landscape ? 4 : 3;
    const gap = 4;
    const cw = (p.cw - gap * (per - 1)) / per;
    p.ensure(14 + 28);
    p.rule(p.y, 0.3);
    p.y += 7;
    p.sectionTitle(H.custom, 'star');
    d.customMetrics.forEach((m, i) => {
      const col = i % per;
      if (col === 0 && i > 0) p.y += 30;
      if (col === 0) p.ensure(28);
      const x = p.m + col * (cw + gap);
      p.stroke(LINE, 0.3);
      doc.roundedRect(x, p.y, cw, 27, 1.5, 1.5, 'S');
      p.font('semibold', 8, INK);
      p.wrap(m.label, cw - 6).slice(0, 2).forEach((ln, j) => doc.text(ln, x + 3, p.y + 5 + j * 3.4));
      p.font('normal', 6.5, MUTED);
      doc.text(String(prevYear), x + 3, p.y + 14);
      doc.text(String(projYear), x + cw - 3, p.y + 14, { align: 'right' });
      const pv = fmtMetric(m.prev, m.unit, cur);
      const jv = fmtMetric(m.proj, m.unit, cur);
      const sz1 = p.fitSize(pv, 'semibold', 10, cw / 2 - 4, 6);
      p.font('semibold', sz1, SOFT);
      doc.text(pv, x + 3, p.y + 19);
      const sz2 = p.fitSize(jv, 'bold', 13, cw / 2 - 4, 6);
      p.font('bold', sz2, hex(t.accent));
      doc.text(jv, x + cw - 3, p.y + 19.5, { align: 'right' });
      const c = metricChange(m);
      p.font('normal', 6.5, MUTED);
      doc.text(c.kind === 'na' ? (c.reason === 'missing' ? '' : '% change not meaningful') : `${fmtChange(c)} change`, x + 3, p.y + 24.3);
    });
    p.y += 34;
  }

  /* ---------- Other figures ---------- */
  const extras = r.financials.extra.filter((x) => x.label.trim() && (has(x.prev) || has(x.proj)));
  if (extras.length) {
    p.ensure(10 + 16);
    p.font('bold', 11);
    doc.text('Other financial figures', p.m, p.y + 2);
    p.y += 6;
    p.table(
      metricCols(),
      extras.map((x) => [x.label, fmtMoney(x.prev, cur), fmtMoney(x.proj, cur), fmtChange(metricChange({ unit: 'currency', prev: x.prev, proj: x.proj }))]),
    );
    p.y += 6;
  }

  /* ---------- Assumptions ---------- */
  const a = r.assumptions;
  const rows: string[][] = [];
  if (has(a.revenueGrowth)) rows.push(['Expected revenue growth', fmtPct(a.revenueGrowth, 2), d.revenue.change.kind === 'pct' ? fmtChange(d.revenue.change) : '—']);
  if (has(a.expenseGrowth)) rows.push(['Expected expense growth', fmtPct(a.expenseGrowth, 2), d.expenses.change.kind === 'pct' ? fmtChange(d.expenses.change) : '—']);
  if (has(a.customerGrowth)) {
    const reg = r.metrics.find((m) => m.key === 'registered');
    const c = reg ? metricChange(reg) : null;
    rows.push(['Expected customer growth', fmtPct(a.customerGrowth, 2), c && c.kind === 'pct' ? fmtChange(c) : '—']);
  }
  if (has(a.retention)) rows.push(['Assumed customer retention', fmtPct(a.retention, 2), '—']);
  for (const n of a.notes.filter((n) => n.label.trim() || n.value.trim())) rows.push([n.label || 'Assumption', n.value, '—']);
  if (rows.length) {
    p.ensure(14 + 22);
    p.rule(p.y, 0.3);
    p.y += 7;
    p.sectionTitle(H.assumptions, 'list');
    p.table(
      [
        { title: 'Assumption (provided by the business)', w: p.cw * 0.36 },
        { title: 'Value', w: p.cw * 0.42 },
        { title: 'Calculated from figures', w: p.cw * 0.22, align: 'right' },
      ],
      rows,
      { firstColBg: ROWBG },
    );
    p.y += 6;
  }

  /* ---------- Disclaimer ---------- */
  const disc = 'Disclaimer: ' + DISCLAIMER + (r.isSample ? ' This is a demonstration report using a fictional business and invented sample data.' : '');
  p.font('normal', 7.5, SOFT);
  const dl = p.wrap(disc, p.cw - 8);
  const dh = dl.length * p.lineH(7.5, 1.35) + 6;
  p.ensure(dh + 2);
  p.fill([244, 245, 246]);
  doc.roundedRect(p.m, p.y, p.cw, dh, 1.5, 1.5, 'F');
  p.font('normal', 7.5, SOFT);
  dl.forEach((ln, i) => doc.text(ln, p.m + 4, p.y + 4.8 + i * p.lineH(7.5, 1.35)));
  p.y += dh;

  p.footer(r.isSample);
  return doc;
}

export function downloadPdf(r: Report) {
  const doc = buildPdf(r);
  const blob = doc.output('blob');
  downloadBlob(blob, `${fileSafe(r.business.name)}-${r.business.reportingYear}-financial-projection.pdf`);
}
