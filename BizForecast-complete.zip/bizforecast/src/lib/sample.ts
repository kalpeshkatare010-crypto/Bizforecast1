import type { Metric, Report } from '../types';
import { newReport, PRESET_METRICS, uid } from './defaults';

const preset = (key: string, prev: number | null, proj: number | null): Metric => {
  const p = PRESET_METRICS.find((m) => m.key === key)!;
  return { id: uid(), key, label: p.label, unit: p.unit, group: p.group, prev, proj, custom: false };
};

/**
 * Demonstration report for a FICTIONAL business. All figures are invented sample data
 * and the report is clearly labelled as a demonstration everywhere it appears.
 */
export function sampleReport(): Report {
  const r = newReport();
  return {
    ...r,
    isSample: true,
    business: {
      name: 'Lotus Leaf Print Studio',
      category: 'Printing',
      description: 'A fictional print and design studio offering business printing, large-format banners and custom stationery.',
      reportingYear: 2027,
      financialYear: 'FY 2026–27',
      currency: 'INR',
      preparedDate: '2026-11-20',
    },
    financials: {
      prevRevenue: 4860000,
      projRevenue: 5640000,
      prevExpenses: 3920000,
      projExpenses: 4410000,
      prevProfit: null, // calculated: revenue − expenses
      projProfit: null,
      extra: [{ id: uid(), label: 'Equipment investment', prev: 250000, proj: 600000 }],
    },
    metrics: [
      preset('registered', 1265, 1640),
      preset('premium', 210, 265),
      preset('business', 86, 112),
      preset('retention', 64, 72),
      preset('churn', 11, 8),
      preset('website', 38500, 52000),
      preset('blog', 9400, 14800),
      preset('sales', 6120, 7350),
      { id: uid(), key: 'custom', label: 'Average turnaround time (hours)', unit: 'number', group: 'other', prev: 36, proj: 24, custom: true },
      { id: uid(), key: 'custom', label: 'Repeat orders', unit: 'number', group: 'other', prev: 2850, proj: 3600, custom: true },
      { id: uid(), key: 'custom', label: 'Online review rating (out of 5)', unit: 'number', group: 'other', prev: 4.4, proj: 4.6, custom: true },
    ],
    assumptions: {
      revenueGrowth: 16,
      expenseGrowth: 12.5,
      customerGrowth: 30,
      retention: 72,
      notes: [
        { id: uid(), label: 'New equipment', value: 'A large-format printer is added in April, enabling banner and signage orders.' },
        { id: uid(), label: 'Corporate clients', value: 'Two existing corporate contracts are assumed to renew at current volumes.' },
      ],
    },
    custom: { ...r.custom, executiveSummary: '' },
  };
}
