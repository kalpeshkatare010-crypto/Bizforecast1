import type { Report } from '../types';
import { normalise } from './defaults';

/**
 * Reports are stored only in this browser (localStorage). Nothing is sent to any server.
 */
const KEY = 'bizforecast.reports.v1';

function readAll(): Report[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.map(normalise) : [];
  } catch {
    return [];
  }
}

function writeAll(list: Report[]): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(list));
    window.dispatchEvent(new Event('bizforecast:reports'));
    return true;
  } catch {
    return false;
  }
}

export const storage = {
  list(): Report[] {
    return readAll().sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  },
  get(id: string): Report | undefined {
    return readAll().find((r) => r.id === id);
  },
  save(report: Report): boolean {
    const list = readAll();
    const next = { ...report, updatedAt: new Date().toISOString() };
    const i = list.findIndex((r) => r.id === report.id);
    if (i >= 0) list[i] = next;
    else list.push(next);
    return writeAll(list);
  },
  remove(id: string): boolean {
    return writeAll(readAll().filter((r) => r.id !== id));
  },
};

/** Draft of the report currently being edited, so a page refresh doesn't lose work. */
const DRAFT = 'bizforecast.draft.v1';
export const draft = {
  get(): Report | null {
    try {
      const raw = localStorage.getItem(DRAFT);
      return raw ? normalise(JSON.parse(raw)) : null;
    } catch {
      return null;
    }
  },
  set(r: Report) {
    try {
      localStorage.setItem(DRAFT, JSON.stringify(r));
    } catch {
      /* storage full or unavailable */
    }
  },
  clear() {
    try {
      localStorage.removeItem(DRAFT);
    } catch {
      /* ignore */
    }
  },
};
