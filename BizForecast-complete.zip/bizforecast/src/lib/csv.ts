import type { Change } from './calc';
import { derive, has } from './calc';
import type { Num, Report } from '../types';

const esc = (v: string | number | null | undefined) => {
  if (v === null || v === undefined) return '';
  const s = String(v);
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const n = (v: Num) => (has(v) ? String(Math.round(v * 10000) / 10000) : '');
const ch = (c: Change) => (c.kind === 'na' ? '' : String(Math.round(c.value * 100) / 100));

/** Export all report data as CSV. Empty values stay empty (they are not written as zero). */
export function toCsv(r: Report): string {
  const d = derive(r);
  const rows: (string | number | null)[][] = [];
  rows.push(['BizForecast export']);
  rows.push(['Business', r.business.name]);
  rows.push(['Category', r.business.category]);
  rows.push(['Reporting year', r.business.reportingYear]);
  rows.push(['Financial year', r.business.financialYear]);
  rows.push(['Currency', r.business.currency]);
  rows.push(['Prepared on', r.business.preparedDate]);
  if (r.isSample) rows.push(['Note', 'DEMONSTRATION REPORT — fictional sample data']);
  rows.push([]);
  rows.push(['Section', 'Item', 'Previous year', 'Projected', 'Change', 'Change unit', 'Source']);
  rows.push(['Financials', 'Revenue', n(d.revenue.prev), n(d.revenue.proj), ch(d.revenue.change), '%', 'entered']);
  rows.push(['Financials', 'Expenses', n(d.expenses.prev), n(d.expenses.proj), ch(d.expenses.change), '%', 'entered']);
  rows.push(['Financials', 'Profit', n(d.profit.prev.value), n(d.profit.proj.value), ch(d.profit.change), '%', `${d.profit.prev.source} / ${d.profit.proj.source}`]);
  rows.push(['Financials', 'Profit margin (%)', n(d.marginPrev), n(d.marginProj), d.marginChangePp === null ? '' : String(Math.round(d.marginChangePp * 100) / 100), 'pts', 'calculated']);
  for (const x of r.financials.extra) rows.push(['Other figures', x.label, n(x.prev), n(x.proj), '', '', 'entered']);
  for (const m of r.metrics) {
    if (!has(m.prev) && !has(m.proj)) continue;
    const isRate = m.unit === 'percent';
    const c = isRate ? (has(m.prev) && has(m.proj) ? String(Math.round((m.proj - m.prev) * 100) / 100) : '') : (has(m.prev) && m.prev > 0 && has(m.proj) ? String(Math.round(((m.proj - m.prev) / m.prev) * 10000) / 100) : '');
    rows.push([m.custom ? 'Custom KPI' : 'Metric', m.label + (isRate ? ' (%)' : ''), n(m.prev), n(m.proj), c, isRate ? 'pts' : '%', 'entered']);
  }
  const a = r.assumptions;
  const ass: [string, Num][] = [
    ['Expected revenue growth (%)', a.revenueGrowth],
    ['Expected expense growth (%)', a.expenseGrowth],
    ['Expected customer growth (%)', a.customerGrowth],
    ['Assumed retention rate (%)', a.retention],
  ];
  for (const [label, v] of ass) if (has(v)) rows.push(['Assumption', label, '', n(v), '', '', 'user assumption']);
  for (const note of a.notes) rows.push(['Assumption', note.label, '', note.value, '', '', 'user assumption']);
  return rows.map((row) => row.map(esc).join(',')).join('\r\n');
}

export function downloadBlob(content: Blob, filename: string) {
  const url = URL.createObjectURL(content);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export const fileSafe = (s: string) => (s.trim() || 'report').replace(/[^\w\- ]+/g, '').replace(/\s+/g, '-').slice(0, 60);

export function downloadCsv(r: Report) {
  // BOM so Excel opens ₹ and other symbols correctly
  downloadBlob(new Blob(['﻿' + toCsv(r)], { type: 'text/csv;charset=utf-8' }), `${fileSafe(r.business.name)}-${r.business.reportingYear}-data.csv`);
}
