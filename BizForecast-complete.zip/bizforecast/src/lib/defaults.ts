import type { Metric, MetricGroup, MetricUnit, Report, ThemeId } from '../types';

export const uid = () =>
  (globalThis.crypto && 'randomUUID' in globalThis.crypto
    ? globalThis.crypto.randomUUID()
    : Date.now().toString(36) + Math.random().toString(36).slice(2, 10));

export interface PresetMetric {
  key: string;
  label: string;
  unit: MetricUnit;
  group: MetricGroup;
  help: string;
  example: string;
}

/** Optional metrics users can switch on. None are required. */
export const PRESET_METRICS: PresetMetric[] = [
  { key: 'registered', label: 'Registered customers', unit: 'number', group: 'customers', help: 'Total customers or users on record.', example: '1,200' },
  { key: 'premium', label: 'Premium customers', unit: 'number', group: 'customers', help: 'Customers on a paid, premium or higher plan.', example: '150' },
  { key: 'business', label: 'Business customers', unit: 'number', group: 'customers', help: 'Customers that are companies (B2B).', example: '40' },
  { key: 'acquisition', label: 'New customers acquired', unit: 'number', group: 'customers', help: 'New customers gained during the year.', example: '300' },
  { key: 'retention', label: 'Customer retention rate', unit: 'percent', group: 'rates', help: 'Share of customers who stayed with you over the year.', example: '72' },
  { key: 'churn', label: 'Churn rate', unit: 'percent', group: 'rates', help: 'Share of customers who stopped buying or cancelled.', example: '8' },
  { key: 'conversion', label: 'Conversion rate', unit: 'percent', group: 'rates', help: 'Share of visitors or enquiries that became buyers.', example: '3.5' },
  { key: 'website', label: 'Website traffic (visits)', unit: 'number', group: 'traffic', help: 'Total website visits in the year.', example: '50,000' },
  { key: 'blog', label: 'Blog traffic (visits)', unit: 'number', group: 'traffic', help: 'Visits to your blog or articles.', example: '12,000' },
  { key: 'sales', label: 'Sales volume (units / orders)', unit: 'number', group: 'sales', help: 'Number of products sold or orders completed.', example: '8,500' },
  { key: 'subscriptions', label: 'Active subscriptions', unit: 'number', group: 'sales', help: 'Number of active subscriptions or memberships.', example: '600' },
];

export const GROUP_LABEL: Record<MetricGroup, string> = {
  customers: 'Customers',
  traffic: 'Traffic',
  sales: 'Sales',
  rates: 'Rates',
  other: 'Other',
};

export function metricFromPreset(p: PresetMetric): Metric {
  return { id: uid(), key: p.key, label: p.label, unit: p.unit, group: p.group, prev: null, proj: null, custom: false };
}

export const BUSINESS_CATEGORIES = [
  'Retail',
  'Wholesale',
  'Restaurant / Café',
  'Manufacturing',
  'Startup',
  'Service provider',
  'Freelancer',
  'Digital agency',
  'E-commerce',
  'Consultancy',
  'Printing',
  'Education / Training',
  'Healthcare / Wellness',
  'Other',
];

export const THEMES: Record<ThemeId, { name: string; prev: string; proj: string; accent: string; track: string }> = {
  classic: { name: 'Classic (blue & green)', prev: '#7fd3ec', proj: '#86c75f', accent: '#5fae3a', track: '#e1e1e1' },
  ocean: { name: 'Ocean (navy & teal)', prev: '#9db4d6', proj: '#1f9e8f', accent: '#17806f', track: '#e3e7ec' },
  graphite: { name: 'Graphite (grey & green)', prev: '#b9bec6', proj: '#3f9b5a', accent: '#2f7d47', track: '#e6e7e9' },
};

const today = () => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

export function newReport(): Report {
  const now = new Date().toISOString();
  const year = new Date().getFullYear() + 1;
  return {
    id: uid(),
    createdAt: now,
    updatedAt: now,
    isSample: false,
    business: {
      name: '',
      category: '',
      description: '',
      reportingYear: year,
      financialYear: `FY ${year - 1}–${String(year).slice(2)}`,
      currency: 'INR',
      preparedDate: today(),
    },
    financials: {
      prevRevenue: null,
      projRevenue: null,
      prevExpenses: null,
      projExpenses: null,
      prevProfit: null,
      projProfit: null,
      extra: [],
    },
    metrics: [],
    assumptions: { revenueGrowth: null, expenseGrowth: null, customerGrowth: null, retention: null, notes: [] },
    custom: {
      kpis: {
        projectedRevenue: true,
        projectedProfit: true,
        revenueGrowth: true,
        profitMargin: true,
        projectedExpenses: false,
        profitGrowth: false,
      },
      charts: { financialComparison: true, customerComparison: true, metricsTable: true, rateDonuts: true },
      headings: {
        title: 'Financial Projection Report',
        summary: 'Executive Summary',
        highlights: 'Financial Highlights',
        comparison: 'Previous Year vs Projection',
        customers: 'Customer Comparison',
        performance: 'Business Performance',
        growth: 'Growth & Retention',
        custom: 'Custom KPIs',
        assumptions: 'Assumptions Behind This Projection',
      },
      executiveSummary: '',
      theme: 'classic',
      orientation: 'portrait',
    },
  };
}

/** Fill in any fields missing from older saved reports. */
export function normalise(r: Partial<Report>): Report {
  const base = newReport();
  return {
    ...base,
    ...r,
    business: { ...base.business, ...r.business },
    financials: { ...base.financials, ...r.financials },
    metrics: r.metrics ?? [],
    assumptions: { ...base.assumptions, ...r.assumptions },
    custom: {
      ...base.custom,
      ...r.custom,
      kpis: { ...base.custom.kpis, ...r.custom?.kpis },
      charts: { ...base.custom.charts, ...r.custom?.charts },
      headings: { ...base.custom.headings, ...r.custom?.headings },
    },
  } as Report;
}
