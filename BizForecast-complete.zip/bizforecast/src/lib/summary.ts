import type { Report } from '../types';
import { derive, fmtMoney, fmtPct, fmtSigned, has } from './calc';

/**
 * Build a plain-language summary strictly from the figures the user entered.
 * It never invents achievements: each sentence is only added when its data exists.
 */
export function autoSummary(r: Report): string {
  const d = derive(r);
  const cur = r.business.currency;
  const name = r.business.name.trim() || 'The business';
  const year = r.business.reportingYear;
  const parts: string[] = [];

  parts.push(
    `This report compares ${name}'s previous-year figures with its projections for ${year}${r.business.financialYear ? ` (${r.business.financialYear})` : ''}.`,
  );

  if (has(d.revenue.proj)) {
    if (d.revenue.change.kind === 'pct') {
      const dir = d.revenue.change.value >= 0 ? 'grow' : 'decline';
      parts.push(
        `Revenue is projected to ${dir} by ${fmtPct(Math.abs(d.revenue.change.value))}, from ${fmtMoney(d.revenue.prev, cur)} to ${fmtMoney(d.revenue.proj, cur)}.`,
      );
    } else {
      parts.push(`Projected revenue is ${fmtMoney(d.revenue.proj, cur)}.`);
    }
  }

  if (has(d.expenses.proj) && d.expenses.change.kind === 'pct') {
    parts.push(`Expenses are expected to ${d.expenses.change.value >= 0 ? 'rise' : 'fall'} by ${fmtPct(Math.abs(d.expenses.change.value))} to ${fmtMoney(d.expenses.proj, cur)}.`);
  }

  if (has(d.profit.proj.value)) {
    const p = d.profit.proj.value;
    const word = p >= 0 ? 'profit' : 'loss';
    let s = `This gives a projected ${word} of ${fmtMoney(Math.abs(p), cur)}`;
    if (d.marginProj !== null) s += ` and a profit margin of ${fmtPct(d.marginProj)}`;
    if (d.marginChangePp !== null && Math.abs(d.marginChangePp) >= 0.05) s += ` (${fmtSigned(d.marginChangePp)} percentage points on last year)`;
    parts.push(s + '.');
  }

  const churn = r.metrics.find((m) => m.key === 'churn');
  if (churn && has(churn.prev) && has(churn.proj) && churn.prev !== churn.proj) {
    parts.push(`Churn is expected to move from ${fmtPct(churn.prev)} to ${fmtPct(churn.proj)}.`);
  }
  if (d.retention) {
    parts.push(
      d.retention.source === 'metric'
        ? `Projected customer retention is ${fmtPct(d.retention.value)}.`
        : `The projection assumes a customer retention rate of ${fmtPct(d.retention.value)}.`,
    );
  }

  parts.push('All projections are estimates based on the figures and assumptions provided.');
  return parts.join(' ');
}

export const summaryText = (r: Report) => r.custom.executiveSummary.trim() || autoSummary(r);
