import type { Num, Report, Metric, MetricUnit } from '../types';

/* ------------------------------------------------------------------ */
/* Parsing                                                             */
/* ------------------------------------------------------------------ */

/** Parse user text into a number. Empty → null. Accepts "1,25,000", "12.5", "-300". Returns NaN for junk. */
export function parseNum(text: string): number | null {
  const t = text.replace(/[\s,_]/g, '').replace(/%$/, '');
  if (t === '') return null;
  if (!/^[-+]?(\d+\.?\d*|\.\d+)$/.test(t)) return NaN;
  return Number(t);
}

export const has = (v: Num): v is number => typeof v === 'number' && Number.isFinite(v);

/* ------------------------------------------------------------------ */
/* Growth / change                                                     */
/* ------------------------------------------------------------------ */

export type Change =
  | { kind: 'pct'; value: number } // percentage change, e.g. 12.5 means +12.5 %
  | { kind: 'pp'; value: number } // percentage-point change (for rates)
  | { kind: 'na'; reason: 'missing' | 'zero-base' | 'negative-base' };

/**
 * Percentage change from prev to proj.
 * A percentage is only meaningful when the starting value is positive; otherwise we
 * return 'na' so the UI can show the absolute change instead of a misleading figure.
 */
export function growth(prev: Num, proj: Num): Change {
  if (!has(prev) || !has(proj)) return { kind: 'na', reason: 'missing' };
  if (prev === 0) return { kind: 'na', reason: 'zero-base' };
  if (prev < 0) return { kind: 'na', reason: 'negative-base' };
  return { kind: 'pct', value: ((proj - prev) / prev) * 100 };
}

/** Change for a metric: percentage points for rates, % change otherwise. */
export function metricChange(m: Pick<Metric, 'unit' | 'prev' | 'proj'>): Change {
  if (m.unit === 'percent') {
    if (!has(m.prev) || !has(m.proj)) return { kind: 'na', reason: 'missing' };
    return { kind: 'pp', value: m.proj - m.prev };
  }
  return growth(m.prev, m.proj);
}

/** Profit margin (%) = profit ÷ revenue. Only defined when revenue is positive. */
export function margin(profit: Num, revenue: Num): number | null {
  if (!has(profit) || !has(revenue) || revenue <= 0) return null;
  return (profit / revenue) * 100;
}

export type Sourced = { value: number | null; source: 'entered' | 'calculated' | 'missing' };

/** Profit as entered, or revenue − expenses when left blank. */
export function effectiveProfit(profit: Num, revenue: Num, expenses: Num): Sourced {
  if (has(profit)) return { value: profit, source: 'entered' };
  if (has(revenue) && has(expenses)) return { value: round2(revenue - expenses), source: 'calculated' };
  return { value: null, source: 'missing' };
}

/** True when an entered profit differs from revenue − expenses by more than 0.5 % of revenue. */
export function profitMismatch(profit: Num, revenue: Num, expenses: Num): number | null {
  if (!has(profit) || !has(revenue) || !has(expenses)) return null;
  const expected = revenue - expenses;
  const tolerance = Math.max(1, Math.abs(revenue) * 0.005);
  return Math.abs(profit - expected) > tolerance ? round2(expected) : null;
}

/** Apply a growth assumption: base × (1 + g/100) */
export function applyGrowth(base: Num, pct: Num): number | null {
  if (!has(base) || !has(pct)) return null;
  return round2(base * (1 + pct / 100));
}

export const round2 = (n: number) => Math.round(n * 100) / 100;

/* ------------------------------------------------------------------ */
/* Derived report figures                                              */
/* ------------------------------------------------------------------ */

export interface Derived {
  revenue: { prev: Num; proj: Num; change: Change };
  expenses: { prev: Num; proj: Num; change: Change };
  profit: { prev: Sourced; proj: Sourced; change: Change };
  marginPrev: number | null;
  marginProj: number | null;
  /** Percentage-point change in margin */
  marginChangePp: number | null;
  customerMetrics: Metric[];
  rateMetrics: Metric[];
  presetMetrics: Metric[];
  customMetrics: Metric[];
  retention: { value: number; prev: Num; source: 'metric' | 'assumption' } | null;
  hasFinancials: boolean;
}

export const metricHasData = (m: Metric) => has(m.prev) || has(m.proj);

export function derive(r: Report): Derived {
  const f = r.financials;
  const pPrev = effectiveProfit(f.prevProfit, f.prevRevenue, f.prevExpenses);
  const pProj = effectiveProfit(f.projProfit, f.projRevenue, f.projExpenses);
  const marginPrev = margin(pPrev.value, f.prevRevenue);
  const marginProj = margin(pProj.value, f.projRevenue);

  const withData = r.metrics.filter(metricHasData);
  const presetMetrics = withData.filter((m) => !m.custom);
  const customMetrics = withData.filter((m) => m.custom);

  const retentionMetric = withData.find((m) => m.key === 'retention' && has(m.proj));
  let retention: Derived['retention'] = null;
  if (retentionMetric && has(retentionMetric.proj)) {
    retention = { value: retentionMetric.proj, prev: retentionMetric.prev, source: 'metric' };
  } else if (has(r.assumptions.retention)) {
    retention = { value: r.assumptions.retention, prev: null, source: 'assumption' };
  }

  return {
    revenue: { prev: f.prevRevenue, proj: f.projRevenue, change: growth(f.prevRevenue, f.projRevenue) },
    expenses: { prev: f.prevExpenses, proj: f.projExpenses, change: growth(f.prevExpenses, f.projExpenses) },
    profit: { prev: pPrev, proj: pProj, change: growth(pPrev.value, pProj.value) },
    marginPrev,
    marginProj,
    marginChangePp: marginPrev !== null && marginProj !== null ? marginProj - marginPrev : null,
    customerMetrics: presetMetrics.filter((m) => m.group === 'customers' && m.unit === 'number'),
    rateMetrics: withData.filter((m) => m.unit === 'percent' && has(m.proj)),
    presetMetrics,
    customMetrics,
    retention,
    hasFinancials: [f.prevRevenue, f.projRevenue, f.prevExpenses, f.projExpenses, pPrev.value, pProj.value].some(has),
  };
}

/* ------------------------------------------------------------------ */
/* Formatting                                                          */
/* ------------------------------------------------------------------ */

export const CURRENCIES: { code: string; label: string }[] = [
  { code: 'INR', label: 'Indian Rupee (₹)' },
  { code: 'USD', label: 'US Dollar ($)' },
  { code: 'EUR', label: 'Euro (€)' },
  { code: 'GBP', label: 'British Pound (£)' },
  { code: 'AED', label: 'UAE Dirham' },
  { code: 'AUD', label: 'Australian Dollar' },
  { code: 'CAD', label: 'Canadian Dollar' },
  { code: 'SGD', label: 'Singapore Dollar' },
  { code: 'JPY', label: 'Japanese Yen (¥)' },
  { code: 'CNY', label: 'Chinese Yuan' },
  { code: 'SAR', label: 'Saudi Riyal' },
  { code: 'ZAR', label: 'South African Rand' },
  { code: 'NGN', label: 'Nigerian Naira (₦)' },
  { code: 'KES', label: 'Kenyan Shilling' },
  { code: 'BDT', label: 'Bangladeshi Taka' },
  { code: 'LKR', label: 'Sri Lankan Rupee' },
  { code: 'NPR', label: 'Nepalese Rupee' },
  { code: 'PKR', label: 'Pakistani Rupee' },
  { code: 'MYR', label: 'Malaysian Ringgit' },
  { code: 'PHP', label: 'Philippine Peso' },
  { code: 'IDR', label: 'Indonesian Rupiah' },
  { code: 'BRL', label: 'Brazilian Real' },
];

const localeFor = (currency: string) => (['INR', 'NPR', 'LKR', 'PKR', 'BDT'].includes(currency) ? 'en-IN' : 'en-US');

export function fmtMoney(v: Num, currency: string, opts: { decimals?: boolean } = {}): string {
  if (!has(v)) return '—';
  const decimals = opts.decimals ?? !Number.isInteger(v);
  try {
    return new Intl.NumberFormat(localeFor(currency), {
      style: 'currency',
      currency,
      currencyDisplay: 'narrowSymbol',
      minimumFractionDigits: decimals ? 2 : 0,
      maximumFractionDigits: decimals ? 2 : 0,
    }).format(v);
  } catch {
    return `${currency} ${fmtNumber(v, currency)}`;
  }
}

/** Short form for chart axes: ₹12.5L, $1.2M */
export function fmtMoneyCompact(v: number, currency: string): string {
  const sym = currencySymbol(currency);
  const sign = v < 0 ? '-' : '';
  const a = Math.abs(v);
  if (localeFor(currency) === 'en-IN') {
    if (a >= 1e7) return `${sign}${sym}${trim(a / 1e7)}Cr`;
    if (a >= 1e5) return `${sign}${sym}${trim(a / 1e5)}L`;
    if (a >= 1e3) return `${sign}${sym}${trim(a / 1e3)}K`;
    return `${sign}${sym}${trim(a)}`;
  }
  if (a >= 1e9) return `${sign}${sym}${trim(a / 1e9)}B`;
  if (a >= 1e6) return `${sign}${sym}${trim(a / 1e6)}M`;
  if (a >= 1e3) return `${sign}${sym}${trim(a / 1e3)}K`;
  return `${sign}${sym}${trim(a)}`;
}

/** Short form for counts; exact below 100,000 so small numbers stay precise. */
export function fmtCompact(v: number): string {
  const a = Math.abs(v);
  if (a < 100000) return new Intl.NumberFormat('en-US', { maximumFractionDigits: 1 }).format(v);
  const sign = v < 0 ? '-' : '';
  if (a >= 1e9) return `${sign}${trim(a / 1e9)}B`;
  if (a >= 1e6) return `${sign}${trim(a / 1e6)}M`;
  if (a >= 1e3) return `${sign}${trim(a / 1e3)}K`;
  return `${sign}${trim(a)}`;
}

const trim = (n: number) => (Math.round(n * 10) / 10).toString();

export function currencySymbol(currency: string): string {
  try {
    const parts = new Intl.NumberFormat('en', { style: 'currency', currency, currencyDisplay: 'narrowSymbol' }).formatToParts(0);
    return parts.find((p) => p.type === 'currency')?.value ?? currency;
  } catch {
    return currency;
  }
}

export function fmtNumber(v: Num, currency = 'USD'): string {
  if (!has(v)) return '—';
  return new Intl.NumberFormat(localeFor(currency), { maximumFractionDigits: 2 }).format(v);
}

export function fmtPct(v: number | null, digits = 1): string {
  if (v === null || !Number.isFinite(v)) return '—';
  return `${trimDigits(v, digits)}%`;
}

const trimDigits = (v: number, d: number) => {
  const s = v.toFixed(d);
  return s.includes('.') ? s.replace(/\.?0+$/, '') : s;
};

export function fmtSigned(v: number, digits = 1): string {
  const s = trimDigits(Math.abs(v), digits);
  if (s === '0') return '0';
  return `${v > 0 ? '+' : '−'}${s}`;
}

export function fmtChange(c: Change): string {
  if (c.kind === 'pct') return `${fmtSigned(c.value)}%`;
  if (c.kind === 'pp') return `${fmtSigned(c.value)} pts`;
  if (c.reason === 'missing') return '—';
  return 'n/a';
}

export function changeHint(c: Change): string | undefined {
  if (c.kind === 'na' && c.reason === 'zero-base') return 'Previous value is zero, so a percentage cannot be calculated.';
  if (c.kind === 'na' && c.reason === 'negative-base') return 'Previous value is negative, so a percentage change would be misleading.';
  if (c.kind === 'pp') return 'Change in percentage points (difference between the two rates).';
  return undefined;
}

export function fmtMetric(v: Num, unit: MetricUnit, currency: string): string {
  if (!has(v)) return '—';
  if (unit === 'percent') return fmtPct(v, 2);
  if (unit === 'currency') return fmtMoney(v, currency);
  return fmtNumber(v, currency);
}

export function fmtDate(iso: string): string {
  if (!iso) return '';
  const d = new Date(iso + (iso.length === 10 ? 'T00:00:00' : ''));
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
}
