import { useEffect, useId, useRef, useState, type ReactNode } from 'react';
import { HelpCircle } from 'lucide-react';
import type { Num } from '../types';
import { parseNum } from '../lib/calc';

export function Field({
  label,
  help,
  error,
  children,
  optional,
  htmlFor,
  badge,
}: {
  label: string;
  help?: ReactNode;
  error?: string;
  children: ReactNode;
  optional?: boolean;
  htmlFor?: string;
  badge?: ReactNode;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-2">
        <label htmlFor={htmlFor} className="text-sm font-semibold text-ink">
          {label}
        </label>
        {optional && <span className="text-xs text-muted">optional</span>}
        {badge}
      </div>
      {children}
      {error ? (
        <p role="alert" className="mt-1 text-xs font-medium text-red-600">
          {error}
        </p>
      ) : help ? (
        <p className="mt-1 text-xs text-muted">{help}</p>
      ) : null}
    </div>
  );
}

const group = (n: number) => {
  // Keep whatever decimals were typed; add thousands separators to the integer part.
  const [i, dec] = String(n).split('.');
  const neg = i.startsWith('-');
  const digits = neg ? i.slice(1) : i;
  const withSep = digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (neg ? '-' : '') + withSep + (dec ? '.' + dec : '');
};

/**
 * Number input that accepts "1,25,000" style text. Empty stays empty (null), never 0.
 * Reports validity to the parent via onValidity.
 */
export function NumberInput({
  value,
  onChange,
  placeholder,
  suffix,
  prefix,
  min,
  max,
  id,
  onValidity,
  ariaLabel,
}: {
  value: Num;
  onChange: (v: Num) => void;
  placeholder?: string;
  suffix?: string;
  prefix?: string;
  min?: number;
  max?: number;
  id?: string;
  onValidity?: (error: string | null) => void;
  ariaLabel?: string;
}) {
  const [text, setText] = useState(value === null ? '' : group(value));
  const [error, setError] = useState<string | null>(null);
  const focused = useRef(false);
  const lastValue = useRef<Num>(value);
  const validityRef = useRef(onValidity);
  validityRef.current = onValidity;
  // When the field disappears (step change, metric removed) its error no longer applies.
  useEffect(() => () => validityRef.current?.(null), []);

  // Sync when value is changed from outside (e.g. "apply assumption")
  useEffect(() => {
    if (!focused.current && value !== lastValue.current) {
      setText(value === null ? '' : group(value));
      lastValue.current = value;
    }
  }, [value]);

  const validate = (t: string): { v: Num; err: string | null } => {
    const v = parseNum(t);
    if (v === null) return { v: null, err: null };
    if (Number.isNaN(v)) return { v: null, err: 'Please enter a number only, e.g. 125000 or 12.5' };
    if (min !== undefined && v < min) return { v, err: min === 0 ? 'This value cannot be negative.' : `Must be at least ${min}.` };
    if (max !== undefined && v > max) return { v, err: `Must be ${max} or less.` };
    return { v, err: null };
  };

  return (
    <div>
      <div className="relative">
        {prefix && <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted">{prefix}</span>}
        <input
          id={id}
          aria-label={ariaLabel}
          inputMode="decimal"
          className={`input tabular-nums ${prefix ? 'pl-9' : ''} ${suffix ? 'pr-10' : ''} ${error ? 'input-error' : ''}`}
          value={text}
          placeholder={placeholder}
          aria-invalid={!!error}
          onFocus={() => (focused.current = true)}
          onChange={(e) => {
            const t = e.target.value;
            setText(t);
            const { v, err } = validate(t);
            setError(err);
            onValidity?.(err);
            if (!err) {
              lastValue.current = v;
              onChange(v);
            }
          }}
          onBlur={() => {
            focused.current = false;
            const { v, err } = validate(text);
            if (!err && v !== null) setText(group(v));
          }}
        />
        {suffix && <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted">{suffix}</span>}
      </div>
      {error && (
        <p role="alert" className="mt-1 text-xs font-medium text-red-600">
          {error}
        </p>
      )}
    </div>
  );
}

/** Tracks validation errors from many NumberInputs. */
export function useErrors() {
  const [errors, setErrors] = useState<Record<string, string>>({});
  const reporter = (key: string) => (err: string | null) =>
    setErrors((e) => {
      if (!err && !(key in e)) return e;
      const n = { ...e };
      if (err) n[key] = err;
      else delete n[key];
      return n;
    });
  const clear = (prefix: string) =>
    setErrors((e) => Object.fromEntries(Object.entries(e).filter(([k]) => !k.startsWith(prefix))));
  return { errors, reporter, clear, count: Object.keys(errors).length };
}

export function Tip({ children }: { children: ReactNode }) {
  const id = useId();
  const [open, setOpen] = useState(false);
  return (
    <span className="relative inline-flex">
      <button type="button" aria-describedby={id} className="text-muted hover:text-ink" onClick={() => setOpen((o) => !o)} onBlur={() => setOpen(false)} aria-label="Explain">
        <HelpCircle size={14} />
      </button>
      {open && (
        <span id={id} role="tooltip" className="absolute left-1/2 top-6 z-20 w-60 -translate-x-1/2 rounded-lg bg-ink px-3 py-2 text-xs font-normal leading-relaxed text-white shadow-lg">
          {children}
        </span>
      )}
    </span>
  );
}

export function Badge({ kind, children }: { kind: 'calc' | 'assume' | 'sample'; children: ReactNode }) {
  const cls = {
    calc: 'bg-sky-50 text-sky-800 border-sky-200',
    assume: 'bg-violet-50 text-violet-800 border-violet-200',
    sample: 'bg-amber-50 text-amber-900 border-amber-300',
  }[kind];
  return <span className={`inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold ${cls}`}>{children}</span>;
}

export function Toggle({ checked, onChange, label, help }: { checked: boolean; onChange: (v: boolean) => void; label: string; help?: string }) {
  return (
    <label className="flex cursor-pointer items-start gap-3 rounded-lg border border-line bg-white p-3 hover:border-ink/30">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="mt-0.5 h-4 w-4 accent-[#171a1f]" />
      <span>
        <span className="block text-sm font-medium">{label}</span>
        {help && <span className="block text-xs text-muted">{help}</span>}
      </span>
    </label>
  );
}
