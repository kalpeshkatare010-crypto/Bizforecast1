import { NavLink, Outlet, Link } from 'react-router-dom';
import { Plus, WifiOff } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Wordmark } from './Brand';

function useOnline() {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  return online;
}

const navCls = ({ isActive }: { isActive: boolean }) =>
  `px-3 py-2 rounded-lg text-sm font-medium transition ${isActive ? 'text-ink bg-black/5' : 'text-muted hover:text-ink'}`;

export default function Layout() {
  const online = useOnline();
  return (
    <div className="flex min-h-screen flex-col">
      <header className="no-print sticky top-0 z-30 border-b border-line bg-white/90 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
          <Wordmark />
          <nav className="flex items-center gap-1">
            <NavLink to="/dashboard" className={navCls}>
              Dashboard
            </NavLink>
            <NavLink to="/about" className={(s) => `${navCls(s)} hidden sm:block`}>
              About
            </NavLink>
            <Link to="/new" className="btn-primary btn ml-1 !px-3 !py-2">
              <Plus size={16} />
              <span className="hidden sm:inline">New report</span>
            </Link>
          </nav>
        </div>
        {!online && (
          <div className="flex items-center justify-center gap-2 bg-amber-50 py-1.5 text-xs text-amber-800">
            <WifiOff size={13} /> You're offline — BizForecast still works and your reports stay saved on this device.
          </div>
        )}
      </header>
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="no-print border-t border-line bg-white">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-5 text-xs text-muted sm:flex-row">
          <span>Your reports are stored only on this device. Nothing is uploaded.</span>
          <Link to="/about" className="inline-flex items-center gap-1.5 hover:text-ink">
            <img src="./rk-logo.png" alt="" width={16} height={16} className="h-4 w-4" />
            Developed by RK Digitals
          </Link>
        </div>
      </footer>
    </div>
  );
}
