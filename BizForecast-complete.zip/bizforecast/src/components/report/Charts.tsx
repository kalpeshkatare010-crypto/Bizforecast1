import { Bar, BarChart, CartesianGrid, Cell, LabelList, Pie, PieChart, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { fmtCompact, fmtMoneyCompact } from '../../lib/calc';

export interface BarDatum {
  name: string;
  prev: number | null;
  proj: number | null;
}

export function ComparisonBars({
  data,
  colors,
  currency,
  prevLabel,
  projLabel,
  height = 240,
}: {
  data: BarDatum[];
  colors: { prev: string; proj: string };
  currency?: string;
  prevLabel: string;
  projLabel: string;
  height?: number;
}) {
  const fmt = (v: unknown) => {
    if (typeof v !== 'number') return '';
    return currency ? fmtMoneyCompact(v, currency) : fmtCompact(v);
  };
  const anyNegative = data.some((d) => (d.prev ?? 0) < 0 || (d.proj ?? 0) < 0);
  return (
    <div>
      <div className="mb-2 flex flex-wrap items-center gap-3 text-[11px] text-ink-soft">
        <span className="inline-flex items-center gap-1.5 rounded bg-[#ececec] px-2 py-1">
          <i className="inline-block h-2.5 w-3.5" style={{ background: colors.prev }} /> {prevLabel}
        </span>
        <span className="inline-flex items-center gap-1.5 rounded bg-[#ececec] px-2 py-1">
          <i className="inline-block h-2.5 w-3.5" style={{ background: colors.proj }} /> {projLabel}
        </span>
      </div>
      <div style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 22, right: 4, left: 4, bottom: 0 }} barGap={6} barCategoryGap="22%">
            <CartesianGrid vertical={false} stroke="#e6e6e6" />
            <XAxis dataKey="name" tickLine={false} axisLine={{ stroke: '#222' }} tick={{ fill: '#222', fontSize: 12 }} interval={0} />
            <YAxis hide domain={anyNegative ? ['auto', 'auto'] : [0, 'auto']} />
            <Bar dataKey="prev" name={prevLabel} fill={colors.prev} isAnimationActive={false}>
              <LabelList dataKey="prev" position="top" formatter={fmt} style={{ fontSize: 11, fill: '#222' }} />
            </Bar>
            <Bar dataKey="proj" name={projLabel} fill={colors.proj} isAnimationActive={false}>
              <LabelList dataKey="proj" position="top" formatter={fmt} style={{ fontSize: 11, fill: '#222' }} />
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

export function Donut({
  value,
  color,
  track,
  size = 200,
  thickness = 0.2,
  label,
  textColor,
}: {
  value: number;
  color: string;
  track: string;
  size?: number;
  thickness?: number;
  label?: string;
  textColor?: string;
}) {
  const v = Math.max(0, Math.min(100, value));
  const data = [
    { k: 'v', n: v },
    { k: 'r', n: 100 - v },
  ];
  const outer = size / 2;
  const inner = outer * (1 - thickness * 1.6);
  return (
    <div className="relative mx-auto" style={{ width: size, height: size }}>
      <PieChart width={size} height={size}>
        <Pie data={data} dataKey="n" startAngle={90} endAngle={-270} innerRadius={inner} outerRadius={outer} stroke="none" isAnimationActive={false}>
          <Cell fill={color} />
          <Cell fill={track} />
        </Pie>
      </PieChart>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="font-bold tracking-tight" style={{ color: textColor ?? color, fontSize: size * 0.22 }}>
          {label ?? `${Math.round(v * 10) / 10}%`}
        </span>
      </div>
    </div>
  );
}
