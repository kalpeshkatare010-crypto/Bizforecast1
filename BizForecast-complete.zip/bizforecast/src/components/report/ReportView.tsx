import type { ReactNode } from 'react';
import { BarChart3, FlaskConical, Info, ListChecks, RotateCcw, Sparkles, Target, Users } from 'lucide-react';
import type { Metric, Report } from '../../types';
import { changeHint, derive, fmtChange, fmtDate, fmtMetric, fmtMoney, fmtPct, fmtSigned, has, metricChange, type Change } from '../../lib/calc';
import { GROUP_LABEL, THEMES } from '../../lib/defaults';
import { summaryText } from '../../lib/summary';
import { ComparisonBars, Donut } from './Charts';

export const DISCLAIMER =
  'Financial projections are estimates based on user-provided information and assumptions. They do not guarantee future business performance and should not be treated as professional accounting, investment or tax advice.';

function IconBadge({ children }: { children: ReactNode }) {
  return <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-ink text-white">{children}</span>;
}

function SectionTitle({ icon, children }: { icon: ReactNode; children: ReactNode }) {
  return (
    <div className="mb-4 flex items-center gap-3">
      <IconBadge>{icon}</IconBadge>
      <h3 className="text-xl font-bold leading-tight tracking-tight text-ink">{children}</h3>
    </div>
  );
}

function ChangeTag({ c, invert = false }: { c: Change; invert?: boolean }) {
  if (c.kind === 'na') {
    return c.reason === 'missing' ? null : (
      <span className="text-xs text-muted" title={changeHint(c)}>
        % change n/a
      </span>
    );
  }
  const good = invert ? c.value < 0 : c.value > 0;
  const neutral = Math.abs(c.value) < 0.05;
  return (
    <span className={`text-xs font-semibold ${neutral ? 'text-muted' : good ? 'text-green-700' : 'text-red-600'}`} title={changeHint(c)}>
      {fmtChange(c)} vs last year
    </span>
  );
}

/** Metrics where a fall is an improvement */
const LOWER_IS_BETTER = new Set(['churn']);

function MetricTable({ metrics, report, prevYear, projYear, colors }: { metrics: Metric[]; report: Report; prevYear: number; projYear: number; colors: { prev: string; proj: string } }) {
  const cur = report.business.currency;
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-separate border-spacing-[2px] text-sm">
        <thead>
          <tr className="text-left">
            <th className="bg-[#dedede] px-3 py-2.5 font-semibold">Metric</th>
            <th className="bg-[#dedede] px-3 py-2.5 text-right font-semibold">{prevYear}</th>
            <th className="bg-[#dedede] px-3 py-2.5 text-right font-semibold">{projYear}</th>
            <th className="bg-[#dedede] px-3 py-2.5 text-right font-semibold">Change</th>
          </tr>
        </thead>
        <tbody>
          {metrics.map((m) => {
            const c = metricChange(m);
            return (
              <tr key={m.id}>
                <td className="bg-[#f3f3f3] px-3 py-2">{m.label}</td>
                <td className="px-3 py-2 text-right tabular-nums" style={{ background: colors.prev + '66' }}>
                  {fmtMetric(m.prev, m.unit, cur)}
                </td>
                <td className="px-3 py-2 text-right tabular-nums" style={{ background: colors.proj + '66' }}>
                  {fmtMetric(m.proj, m.unit, cur)}
                </td>
                <td className="bg-[#f3f3f3] px-3 py-2 text-right tabular-nums" title={changeHint(c)}>
                  {fmtChange(c)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default function ReportView({ report }: { report: Report }) {
  const r = report;
  const d = derive(r);
  const t = THEMES[r.custom.theme] ?? THEMES.classic;
  const cur = r.business.currency;
  const H = r.custom.headings;
  const k = r.custom.kpis;
  const ch = r.custom.charts;
  const projYear = r.business.reportingYear;
  const prevYear = projYear - 1;
  const prevLabel = `${prevYear} Actual`;
  const projLabel = `${projYear} Projection`;

  const finBars = [
    { name: 'Revenue', prev: d.revenue.prev, proj: d.revenue.proj },
    { name: 'Expenses', prev: d.expenses.prev, proj: d.expenses.proj },
    { name: 'Profit', prev: d.profit.prev.value, proj: d.profit.proj.value },
  ].filter((x) => has(x.prev) || has(x.proj));

  const custBars = d.customerMetrics.map((m) => ({ name: m.label.replace(/ customers$/i, ''), prev: m.prev, proj: m.proj }));

  // Highlights
  const tiles: { label: string; value: string; sub?: ReactNode; big?: boolean }[] = [];
  if (k.projectedRevenue && has(d.revenue.proj)) tiles.push({ label: `Projected revenue ${projYear}`, value: fmtMoney(d.revenue.proj, cur), sub: <ChangeTag c={d.revenue.change} /> });
  if (k.projectedProfit && has(d.profit.proj.value))
    tiles.push({
      label: d.profit.proj.value >= 0 ? `Projected profit ${projYear}` : `Projected loss ${projYear}`,
      value: fmtMoney(d.profit.proj.value, cur),
      sub: d.profit.proj.source === 'calculated' ? <span className="text-xs text-muted">Revenue − expenses</span> : <ChangeTag c={d.profit.change} />,
    });
  if (k.revenueGrowth && d.revenue.change.kind === 'pct') tiles.push({ label: 'Revenue growth', value: fmtChange(d.revenue.change), sub: <span className="text-xs text-muted">vs {prevYear}</span> });
  if (k.profitMargin && d.marginProj !== null)
    tiles.push({
      label: 'Profit margin',
      value: fmtPct(d.marginProj),
      sub: d.marginChangePp !== null ? <span className="text-xs text-muted">{fmtSigned(d.marginChangePp)} pts vs {prevYear}</span> : undefined,
    });
  if (k.projectedExpenses && has(d.expenses.proj)) tiles.push({ label: `Projected expenses ${projYear}`, value: fmtMoney(d.expenses.proj, cur), sub: <ChangeTag c={d.expenses.change} invert /> });
  if (k.profitGrowth && d.profit.change.kind === 'pct') tiles.push({ label: 'Profit growth', value: fmtChange(d.profit.change), sub: <span className="text-xs text-muted">vs {prevYear}</span> });

  const tableMetrics = d.presetMetrics.filter((m) => !(m.group === 'customers' && ch.customerComparison && m.unit === 'number'));
  const groups = (['customers', 'traffic', 'sales', 'rates', 'other'] as const)
    .map((g) => ({ g, items: tableMetrics.filter((m) => m.group === g) }))
    .filter((x) => x.items.length);

  const donuts: { label: string; value: number; caption: string }[] = [];
  if (d.retention) {
    const cap =
      d.retention.source === 'assumption'
        ? '(Your assumption)'
        : has(d.retention.prev)
          ? `(${fmtSigned(d.retention.value - d.retention.prev)} percentage points from ${prevYear})`
          : `(Projected for ${projYear})`;
    donuts.push({ label: 'Projected Customer Retention Rate', value: d.retention.value, caption: cap });
  }
  const otherRates = d.rateMetrics.filter((m) => m.key !== 'retention');
  const smallDonuts: { label: string; value: number; caption: string; invert: boolean }[] = otherRates.map((m) => ({
    label: m.label,
    value: m.proj as number,
    caption: has(m.prev) ? `${fmtPct(m.prev, 2)} in ${prevYear}` : `Projected ${projYear}`,
    invert: LOWER_IS_BETTER.has(m.key),
  }));
  if (d.marginProj !== null && d.marginProj >= 0 && d.marginProj <= 100)
    smallDonuts.push({ label: 'Profit margin', value: d.marginProj, caption: d.marginPrev !== null ? `${fmtPct(d.marginPrev)} in ${prevYear}` : `Projected ${projYear}`, invert: false });

  const showComparison = ch.financialComparison && finBars.length > 0;
  const showCustomers = ch.customerComparison && custBars.length > 0;
  const showTables = ch.metricsTable && groups.length > 0;
  const showDonuts = ch.rateDonuts && (donuts.length > 0 || smallDonuts.length > 0);

  const a = r.assumptions;
  const assumptionRows: { label: string; value: string; calc?: string }[] = [];
  if (has(a.revenueGrowth)) assumptionRows.push({ label: 'Expected revenue growth', value: fmtPct(a.revenueGrowth, 2), calc: d.revenue.change.kind === 'pct' ? fmtChange(d.revenue.change) : undefined });
  if (has(a.expenseGrowth)) assumptionRows.push({ label: 'Expected expense growth', value: fmtPct(a.expenseGrowth, 2), calc: d.expenses.change.kind === 'pct' ? fmtChange(d.expenses.change) : undefined });
  if (has(a.customerGrowth)) {
    const reg = r.metrics.find((m) => m.key === 'registered');
    const c = reg ? metricChange(reg) : null;
    assumptionRows.push({ label: 'Expected customer growth', value: fmtPct(a.customerGrowth, 2), calc: c && c.kind === 'pct' ? fmtChange(c) : undefined });
  }
  if (has(a.retention)) assumptionRows.push({ label: 'Assumed customer retention', value: fmtPct(a.retention, 2) });
  for (const n of a.notes.filter((n) => n.label.trim() || n.value.trim())) assumptionRows.push({ label: n.label || 'Assumption', value: n.value });

  const extras = r.financials.extra.filter((x) => x.label.trim() && (has(x.prev) || has(x.proj)));

  return (
    <article className="@container bg-white px-5 py-8 sm:px-10 sm:py-10 text-ink" id="report-root">
      {r.isSample && (
        <div className="mb-6 flex items-center gap-2 rounded-lg border border-amber-300 bg-amber-50 px-3 py-2 text-xs font-semibold text-amber-900">
          <FlaskConical size={14} /> DEMONSTRATION REPORT — fictional business with sample figures only.
        </div>
      )}

      {/* Header */}
      <header className="text-center">
        <p className="text-lg font-bold sm:text-xl">
          {r.business.name || 'Untitled business'}
          {r.business.category && <span className="ml-2 font-normal italic text-ink-soft">{r.business.category}</span>}
        </p>
        <h1 className="mt-1 text-[28px] font-bold leading-tight tracking-tight sm:text-[38px]">
          {H.title} for {projYear}
        </h1>
        <div className="mt-4 h-[5px] w-full bg-ink" />
        <p className="mt-2 flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs text-muted">
          {r.business.financialYear && <span>{r.business.financialYear}</span>}
          {r.business.preparedDate && <span>Prepared {fmtDate(r.business.preparedDate)}</span>}
          <span>Currency: {cur}</span>
        </p>
      </header>

      {/* Summary + comparison chart */}
      <section className="mt-8 grid gap-8 @2xl:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] avoid-break">
        <div>
          <h2 className="sr-only">{H.summary}</h2>
          <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-muted">{H.summary}</p>
          <p className="whitespace-pre-line text-[15px] leading-relaxed text-ink-soft">{summaryText(r)}</p>
          {has(d.revenue.proj) && (
            <div className="mt-5">
              <p className="text-xs text-muted">Projected revenue for {projYear}</p>
              <p className="break-words text-[34px] font-bold leading-none tracking-tight @md:text-[42px]" style={{ color: t.accent }}>
                {fmtMoney(d.revenue.proj, cur)}
              </p>
            </div>
          )}
        </div>
        {showComparison && (
          <div>
            <div className="flex items-start gap-3">
              <IconBadge>
                <BarChart3 size={20} />
              </IconBadge>
              <div className="min-w-0 flex-1">
                <h3 className="text-base font-bold">{H.comparison}</h3>
              </div>
            </div>
            <div className="mt-3">
              <ComparisonBars data={finBars} colors={t} currency={cur} prevLabel={prevLabel} projLabel={projLabel} />
            </div>
            {(d.profit.prev.source === 'calculated' || d.profit.proj.source === 'calculated') && <p className="mt-1 text-[11px] text-muted">Profit calculated as revenue minus expenses.</p>}
          </div>
        )}
      </section>

      {/* Highlights */}
      {tiles.length > 0 && (
        <section className="mt-10 avoid-break">
          <div className="mb-4 h-px bg-ink/80" />
          <h2 className="mb-4 text-xl font-bold tracking-tight">{H.highlights}</h2>
          <div className="grid grid-cols-1 gap-3 @md:grid-cols-2 @3xl:grid-cols-4">
            {tiles.map((x) => (
              <div key={x.label} className="rounded-lg border border-line px-4 py-4">
                <p className="text-xs font-medium text-muted">{x.label}</p>
                <p className="mt-1 break-words text-2xl font-bold tracking-tight">{x.value}</p>
                <div className="mt-1 min-h-4">{x.sub}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Performance & growth */}
      {(showCustomers || showTables || showDonuts) && (
        <section className="mt-10">
          <div className="mb-8 h-px bg-ink/80" />
          <div className={`grid gap-10 ${showDonuts && (showCustomers || showTables) ? '@3xl:grid-cols-2 @3xl:divide-x @3xl:divide-ink/70' : ''}`}>
            {(showCustomers || showTables) && (
              <div className="space-y-10 @3xl:pr-8">
                {showCustomers && (
                  <div className="avoid-break">
                    <SectionTitle icon={<Users size={20} />}>{H.customers}</SectionTitle>
                    <ComparisonBars data={custBars} colors={t} prevLabel={prevLabel} projLabel={projLabel} height={220} />
                  </div>
                )}
                {showTables && (
                  <div>
                    <SectionTitle icon={<Target size={20} />}>{H.performance}</SectionTitle>
                    <div className="space-y-6">
                      {groups.map(({ g, items }) => (
                        <div key={g} className="avoid-break">
                          {groups.length > 1 && <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-muted">{GROUP_LABEL[g]}</p>}
                          <MetricTable metrics={items} report={r} prevYear={prevYear} projYear={projYear} colors={t} />
                        </div>
                      ))}
                    </div>
                    {groups.some((x) => x.items.some((m) => m.unit === 'percent')) && <p className="mt-2 text-[11px] text-muted">For rates, change is shown in percentage points (pts).</p>}
                  </div>
                )}
              </div>
            )}
            {showDonuts && (
              <div className="avoid-break @3xl:pl-8">
                <SectionTitle icon={<RotateCcw size={20} />}>{H.growth}</SectionTitle>
                {donuts.map((x) => (
                  <div key={x.label} className="text-center">
                    <p className="mb-3 text-sm font-semibold text-ink-soft">{x.label}</p>
                    <Donut value={x.value} color={t.proj} track={t.track} size={230} textColor={t.accent} />
                    <p className="mt-3 text-xs italic text-ink-soft">{x.caption}</p>
                  </div>
                ))}
                {smallDonuts.length > 0 && (
                  <div className={`grid grid-cols-2 gap-6 ${donuts.length ? 'mt-8' : ''}`}>
                    {smallDonuts.map((x) => (
                      <div key={x.label} className="text-center">
                        <Donut value={x.value} color={x.invert ? t.prev : t.proj} track={t.track} size={120} textColor="#171a1f" label={fmtPct(x.value)} />
                        <p className="mt-2 text-xs font-semibold">{x.label}</p>
                        <p className="text-[11px] text-muted">{x.caption}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </section>
      )}

      {/* Custom KPIs */}
      {d.customMetrics.length > 0 && (
        <section className="mt-10 avoid-break">
          <div className="mb-8 h-px bg-ink/80" />
          <SectionTitle icon={<Sparkles size={20} />}>{H.custom}</SectionTitle>
          <div className="grid grid-cols-1 gap-3 @md:grid-cols-2 @3xl:grid-cols-3">
            {d.customMetrics.map((m) => {
              const c = metricChange(m);
              return (
                <div key={m.id} className="rounded-lg border border-line p-4">
                  <p className="text-sm font-semibold">{m.label}</p>
                  <div className="mt-2 flex items-end justify-between gap-2">
                    <div>
                      <p className="text-[11px] text-muted">{prevYear}</p>
                      <p className="text-lg font-semibold tabular-nums" style={{ color: '#3a3f47' }}>
                        {fmtMetric(m.prev, m.unit, cur)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-[11px] text-muted">{projYear}</p>
                      <p className="text-2xl font-bold tabular-nums" style={{ color: t.accent }}>
                        {fmtMetric(m.proj, m.unit, cur)}
                      </p>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-muted" title={changeHint(c)}>
                    {c.kind === 'na' ? (c.reason === 'missing' ? '' : '% change not meaningful') : `${fmtChange(c)} change`}
                  </p>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Other figures */}
      {extras.length > 0 && (
        <section className="mt-10 avoid-break">
          <h3 className="mb-3 text-base font-bold">Other financial figures</h3>
          <MetricTable
            metrics={extras.map((x) => ({ id: x.id, key: 'extra', label: x.label, unit: 'currency', group: 'other', prev: x.prev, proj: x.proj, custom: true }))}
            report={r}
            prevYear={prevYear}
            projYear={projYear}
            colors={t}
          />
        </section>
      )}

      {/* Assumptions */}
      {assumptionRows.length > 0 && (
        <section className="mt-10 avoid-break">
          <div className="mb-8 h-px bg-ink/80" />
          <SectionTitle icon={<ListChecks size={20} />}>{H.assumptions}</SectionTitle>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ink/70 text-left">
                  <th className="py-2 pr-3 font-semibold">Assumption (provided by the business)</th>
                  <th className="py-2 pr-3 font-semibold">Value</th>
                  <th className="py-2 font-semibold">Calculated from figures</th>
                </tr>
              </thead>
              <tbody>
                {assumptionRows.map((x, i) => (
                  <tr key={i} className="border-b border-line align-top">
                    <td className="py-2 pr-3">{x.label}</td>
                    <td className="py-2 pr-3 font-medium">{x.value}</td>
                    <td className="py-2 text-muted">{x.calc ?? '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* Disclaimer + footer */}
      <section className="mt-10 avoid-break">
        <div className="flex gap-2 rounded-lg bg-[#f4f5f6] p-3 text-[11px] leading-relaxed text-ink-soft">
          <Info size={14} className="mt-0.5 shrink-0" />
          <p>
            <strong>Disclaimer:</strong> {DISCLAIMER}
            {r.isSample && ' This is a demonstration report using a fictional business and invented sample data.'}
          </p>
        </div>
        <div className="mt-6 flex items-center justify-center gap-1.5 border-t border-line pt-4 text-[11px] text-muted">
          <img src="./rk-logo.png" alt="RK Digitals logo" width={14} height={14} className="h-3.5 w-3.5" />
          BizForecast | Generated using RK Digitals
        </div>
      </section>
    </article>
  );
}
