import { Link } from 'react-router-dom';

export function BizMark({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <rect width="32" height="32" rx="7" fill="#171a1f" />
      <rect x="6.4" y="16.6" width="3.8" height="8.4" rx="0.9" fill="#7fd3ec" />
      <rect x="11.5" y="12.8" width="3.8" height="12.2" rx="0.9" fill="#86c75f" />
      <rect x="17.3" y="14.1" width="3.8" height="10.9" rx="0.9" fill="#7fd3ec" />
      <rect x="22.4" y="7.7" width="3.8" height="17.3" rx="0.9" fill="#86c75f" />
      <rect x="5.1" y="25.6" width="22.4" height="0.9" fill="#fff" opacity="0.9" />
    </svg>
  );
}

export function Wordmark({ to = '/' }: { to?: string }) {
  return (
    <Link to={to} className="flex items-center gap-2.5 font-bold tracking-tight text-ink text-lg">
      <BizMark />
      <span>BizForecast</span>
    </Link>
  );
}

/** Subtle publisher attribution — never the dominant brand. */
export function RkAttribution({ className = '' }: { className?: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 text-xs text-muted ${className}`}>
      <img src="./rk-logo.png" alt="RK Digitals logo" width={16} height={16} className="h-4 w-4 opacity-90" />
      <span>BizForecast | Generated using RK Digitals</span>
    </span>
  );
}
