import { Component, type ReactNode } from 'react';

/** Shows a friendly message instead of a blank screen if something unexpected breaks. */
export default class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };
  static getDerivedStateFromError(error: Error) {
    return { error };
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <p className="text-lg font-semibold">Something went wrong</p>
        <p className="mt-2 text-sm text-muted">Your saved reports are safe on this device. Please reload the page.</p>
        <button className="btn-primary btn mt-6" onClick={() => (window.location.href = './#/dashboard', window.location.reload())}>
          Reload BizForecast
        </button>
      </div>
    );
  }
}
