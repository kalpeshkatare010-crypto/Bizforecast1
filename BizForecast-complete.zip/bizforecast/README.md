# BizForecast

Universal financial projection report generator. Developed and published by **RK Digitals**.

Enter business details, last year's figures and next year's projections, choose relevant metrics, and BizForecast calculates growth, profit and margin and produces a professional report you can preview, print, download as an A4 PDF (portrait or landscape) or export as CSV.

- No account, no server, no tracking. Reports are saved in the browser (localStorage) on the user's device only.
- Installable Progressive Web App (PWA); works offline after the first visit, including PDF export.
- Built with React, TypeScript, Tailwind CSS, Recharts, Lucide icons and jsPDF (vector PDF with embedded Inter font).

## Quick start (for developers)

Requires Node.js 20 or newer.

```bash
npm install
npm run dev        # development server at http://localhost:5173
npm test           # unit tests for the financial calculations
npm run build      # production build into dist/
npm run preview    # serve the production build at http://localhost:4173
```

## Using the ready-made build (no coding needed)

The `dist/` folder is a complete, ready-to-host website. You do not need to build anything.

### Netlify (easiest)
1. Go to https://app.netlify.com/drop (free account required).
2. Drag the **dist** folder (unzipped `BizForecast-website.zip`) onto the page.
3. Netlify gives you a link such as `https://your-name.netlify.app`. Rename it in *Site configuration → Change site name*.

To build from source on Netlify instead: push this project to GitHub, choose *Add new site → Import from Git*. `netlify.toml` already sets the build command (`npm run build`) and publish folder (`dist`).

### Vercel
1. Push this project to a GitHub repository.
2. In Vercel choose *Add New → Project*, import the repository. `vercel.json` already sets the build settings (framework preset: Vite).
3. Deploy.

### Any other static host
Upload the contents of `dist/` to any web server or static host (GitHub Pages, Cloudflare Pages, cPanel hosting…). The app uses relative paths and hash-based URLs, so it works from any folder without server rewrites. HTTPS is needed for installation and offline mode.

## Installing as an app
Open the hosted site, then:
- **Android (Chrome):** menu ⋮ → *Install app* / *Add to Home screen*.
- **iPhone (Safari):** Share → *Add to Home Screen*.
- **Desktop (Chrome/Edge):** install icon in the address bar.

After the first visit the app works offline.

## Project structure

```
src/
  types.ts                  Data model (Report, Metric, etc.)
  lib/calc.ts               All financial calculations and number formatting
  lib/summary.ts            Executive summary generated only from entered figures
  lib/pdf.ts                Vector PDF generator (jsPDF)
  lib/csv.ts                CSV export
  lib/storage.ts            Local storage (saved reports + unfinished draft)
  lib/defaults.ts           Metric catalogue, themes, new-report defaults
  lib/sample.ts             Demonstration report (fictional business)
  lib/calc.test.ts          Unit tests
  components/report/        Report view and charts
  components/form.tsx       Inputs with validation
  pages/                    Landing, Dashboard, Wizard (5 steps), Preview, About
public/                     App icons and RK Digitals logo
```

## Calculation rules
- Growth % = (projected − previous) ÷ previous × 100. Shown as "n/a" when the previous value is zero or negative (avoids division by zero and misleading percentages).
- Profit = revenue − expenses unless the user enters their own profit; a mismatch shows a warning.
- Profit margin = profit ÷ revenue × 100, only when revenue is above zero.
- Rates (retention, churn, conversion) change in percentage points.
- Empty fields are `null`, never zero, and are hidden in the report, charts and CSV.

## Customising branding
- Publisher logo: `public/rk-logo.png` (web) and `src/assets/rkLogo.ts` (PDF, base64 PNG).
- App icons: `public/pwa-*.png`, `public/apple-touch-icon.png`, `public/favicon.png`.
- Theme colours: `THEMES` in `src/lib/defaults.ts`.

## Licences
Inter font: SIL Open Font License 1.1. Libraries are MIT/Apache licensed (see `node_modules/*/LICENSE`).

## Disclaimer
Financial projections are estimates based on user-provided information and assumptions. They do not guarantee future business performance and should not be treated as professional accounting, investment or tax advice.

© RK Digitals
